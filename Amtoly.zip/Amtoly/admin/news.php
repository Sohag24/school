<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
         <link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>
    
  <?php  
    
    if($_POST["n"]!="")
    {
        
        $news=$_POST["n"];
        $id=1;
mysql_connect("localhost","root","");
mysql_select_db("admin");

mysql_query('SET CHARACTER SET utf8');
        mysql_query('SET SESSION collation_connection =utf8_general_ci') or die (mysql_error());

    mysql_query("insert into news values('$id','$news')");
        
        
         echo "<script type=\"text/javascript\">

          alert(\"News Successfully Uploaded\");
              
         </script>";
        
        
         echo "<script language=\"Javascript\">document.location.href='panel.php?page=Admin' ;</script>";
        
    }
    else
    {
        
           echo "<script type=\"text/javascript\">

          alert(\"Please write Notice\");
              
         </script>";
        
        
         echo "<script language=\"Javascript\">document.location.href='panel.php?page=Admin' ;</script>";
    }
    
    
    
    
    
    
     ?>
  


</body>
</html>
