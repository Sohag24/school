



<html>
    <head>
      
        <link rel="stylesheet" type="text/css" href="style.css">
        
        
    </head>
    <body>

 
     <?php 
        
        
        $name=$_POST["n"];
        $pass=$_POST["p"];
        
        if($name=='amtolihs' && $pass=='1234')
        {
            echo "<script language=\"Javascript\">document.location.href='panel.php?page=Admin' ;</script>";
        }
        else
        {
            
           
          echo "<script type=\"text/javascript\">

          alert(\"Wrong Username Or Password\");
              
         </script>";
        
        
         
            
          
        }
        
        ?>
        
        <div class="login">
  <div class="heading">
    <h2>Sign in</h2>
    <form action="validity.php" method="post">

      <div class="input-group input-group-lg">
        <span class="input-group-addon"><i class="fa fa-user"></i></span>
        <input type="text"  class="form-control"  placeholder="Username or email" name="n">
          </div>
         <br><br>
        <div class="input-group input-group-lg">
          <span class="input-group-addon"><i class="fa fa-lock"></i></span>
          <input type="password" class="form-control" placeholder="Password" name="p" >
        </div>
  <br><br>
        <button type="submit" class="float">Log in</button>
       </form>
 		</div>
 </div>
     
    
  
 		
 
        
        
        
      
        
        
    </body>
</html>