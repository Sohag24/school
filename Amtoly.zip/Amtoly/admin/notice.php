<?php
$target_dir = "";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        
        $id;
       $date=date("Y-m-d");
        $title=$_POST["t"];
        $name=$_FILES["fileToUpload"]["name"];
      mysql_connect("localhost","amtolihs_sohag","mksbshrmaiu123");
mysql_select_db("amtolihs_admin");

mysql_query('SET CHARACTER SET utf8');
        mysql_query('SET SESSION collation_connection =utf8_general_ci') or die (mysql_error());

    mysql_query("insert into notice values('$id','$title','$name','$date')");
        
        
        
        echo "<script type=\"text/javascript\">

          alert(\"Notice Successfully Uploaded\");
              
         </script>";
        
        
         echo "<script language=\"Javascript\">document.location.href='panel.php?page=Admin' ;</script>";

        
    } else {
        
        echo "<script type=\"text/javascript\">

          alert(\"Notice not Uploaded\");
              
         </script>";
        
        
         echo "<script language=\"Javascript\">document.location.href='panel.php?page=Admin' ;</script>";
    }
}






?> 