<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
         <link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>
    
    
    
    <div class="login">
  <div class="heading">
    <h2>News</h2>
    <form action="news.php" method="post">

      <div class="input-group input-group-lg">
        <span class="input-group-addon"><i class="fa fa-user"></i></span>
        <input type="text"  class="form-control"  placeholder="Write News here" name="n">
          </div>
        
        
  <br>
        <button type="submit" class="float">Upload</button>
       </form>
 		</div>
 </div>
    
    
    
    
    
    
     <div class="login">
  <div class="heading">
    <h2>Notice</h2>

    
    <form action="notice.php" method="post" enctype="multipart/form-data">
        
        <div class="input-group input-group-lg">
        <span class="input-group-addon"><i class="fa fa-user"></i></span>
        <input type="text"  class="form-control"  placeholder="Write Notice Title" name="t">
          </div>
   <br>
    <input type="file" name="fileToUpload" id="fileToUpload">
        
        <br>
        
    <input type="submit" class="float" value="Upload" name="submit">
        
</form>
      
      
 		</div>
 </div>
 
  


</body>
</html>
