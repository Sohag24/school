<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <link rel="stylesheet" href="styles.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
<title>Amtoli High School</title>
<link rel="shortcut icon" href="tl.png" type="image/type" />
<link rel="stylesheet" type="text/css" href="style.css" />


<link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
		<script type="text/javascript" src="js/modernizr.custom.29473.js"></script>


 <style>
      #map {
        width: 300px;
        height:200px;
      }
</style>
<script src="https://maps.googleapis.com/maps/api/js"></script>
    <script>
      function initialize() {
        var mapCanvas = document.getElementById('map');
        var mapOptions = {
          center: new google.maps.LatLng(25.8595937,88.6423741),
          zoom: 8,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map(mapCanvas, mapOptions)
      }
      google.maps.event.addDomListener(window, 'load', initialize);
    </script>


</head>

<body>

 
  <div id="container">
  
     <div id="header">
	 
	 </div>
<br>
	 
	<div id='cssmenu'>
<ul>
   <li><a href='index.php'><span>হোম পেজ</span></a></li>
   <li class='has-sub'><a href='#'><span>স্কুল প্রশাসন</span></a>
      <ul>
         <li class='has-sub'><a href='head.php'><span>প্রধান শিক্ষক</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='ahead.php'><span>সহকারী প্রধান শিক্ষক</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='assit.php'><span>শিক্ষক বৃন্দ</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>শ্রেণি শিক্ষকবৃন্দ</span></a>
           
         </li>
		  
		  
		  <li class='has-sub'><a href='#'><span>কমর্কর্তা-কর্মচারী</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>পিটিএ</span></a>
          
         </li>
       
	   
	     <li class='has-sub'><a href='#'><span>পরিচালনা পরিষদ</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>প্রাক্তন প্রধান শিক্ষকবৃন্দ</span></a>
          
         </li>
       
		 
      </ul>
   </li>
   
   
   
   
   
   
    <li class='has-sub'><a href='#'><span>প্রাতিষ্ঠানিক কার্যক্রম</span></a>
      <ul>
         <li class='has-sub'><a href='#'><span>ক্লাস কার্যক্রম</span></a>
           <ul>
               <li><a href='#'><span>ক্লাস VI</span></a></li>
			    <li><a href='#'><span>ক্লাস VII</span></a></li>
				 <li><a href='#'><span>ক্লাস VIII</span></a></li>
				  <li><a href='#'><span>ক্লাস XI</span></a></li>
				   <li><a href='#'><span>ক্লাস X</span></a></li>
			  
			  
            </ul>
         </li>
		
		  <li class='has-sub'><a href='#'><span>বাৎসরিক কার্যক্রম</span></a>
            
         </li>
		 
		  <li class='has-sub'><a href='#'><span>পাঠ্যক্রম</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>কোর্স সমুহ</span></a>
           
         </li>
		  
		  
		  <li class='has-sub'><a href='#'><span>পরীক্ষার ফল</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>ডকুমেন্টারি</span></a>
          
         </li>
       
	   
	    
       
		 
      </ul>
   </li>
   
   
  
  
  
  
  
  
   <li class='has-sub'><a href='#'><span>অন্যান্য তথ্য</span></a>
      <ul>
         <li class='has-sub'><a href='history.php'><span>স্কুল ইতিহাস</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>নিয়ম কানুন</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>পাঠাগার</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>ছাত্রাবাস</span></a>
           
         </li>
		  
		  
		  <li class='has-sub'><a href='#'><span>প্রয়োজনীয় ডাউনলোড</span></a>
           
         </li>
		 
		 
       
		 
      </ul>
   </li>
   
  
  
 
   
  
  
  
 
  
  
  
   <li class='has-sub'><a href='#'><span>সহপাঠ কাযর্ক্রম</span></a>
      <ul>
         <li class='has-sub'><a href='#'><span>DEBATE CLUB</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>ICT CLUB</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>SCIENCE CLUB</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>LANGUAGE CLUB</span></a>
           
         </li>
		  
		  
		  <li class='has-sub'><a href='#'><span>CULTURAL CLUB</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>ENVIRONMENT CLUB</span></a>
          
         </li>
       
	   
	     <li class='has-sub'><a href='#'><span>SCOUTING</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>BNCC</span></a>
          
         </li>
		 
		  <li class='has-sub'><a href='#'><span>অন্যান্য স্কুল কার্যক্রম</span></a>
          
         </li>
       
		 
      </ul>
   </li>
   
   
   
   
  
   
 
  
   
   <li class='last'><a href='#'><span>ভর্তি তথ্য</span></a></li>
   
   <li class='last'><a href='#'><span>রেজাল্ট অনুসন্ধান</span></a></li>
   
  
   
  
</ul>

 
</div>

<div id="mar">
    
    <marquee onmouseover="this.setAttribute('scrollamount', 0, 0);" onmouseout="this.setAttribute('scrollamount', 6, 0);" style="margin-left:80px; margin-top:1px; color:black; letter-spacing:2px;" >৩১/০১/২০১৬ তারিখে আমতলী উচ্চ বিদ্যালয়ের ওয়েব সাইটটি উদ্বোধন করা হয়েছে। ওয়েব সাইটটির আপগ্রেডের কাজ চলছে। </marquee>
 
      
      </div>


<div id="slider">


<div id="body1">

<p>সহকারী প্রধান শিক্ষক</p>

<div id="hpic">

  <img src="Teacher/Khalekujjaman.png" height="250px" width="200px" style="margin-top:100px; margin-left:20px; border:solid; border-width:thick;"  />

</div>

<div id="hinfo">

<h1 style="margin-left:20px; font-size:30px; font-family:Georgia, "Times New Roman", Times, serif;"><b>Md. Khalekuzzaman</b></h1>
<hr />

<h4 style="margin-left:20px; font-size:16px;">পদবী :Assistent Head Teacher <br />
পিতার নাম : Late-Nizam Uddin<br/> 
শিক্ষাগত যোগ্যতা : B.Sc ; B.Ed. <br/>                     
ট্রেনিং : C.P.D-1;C.P.D-2;<br/>
ইমেইল : <br/>   
রক্তের গ্রুপ : O(+)ve <br/>     
জাতীয়তা : Bangladeshi<br/>
জাতীয় পরিচয় নং : 2721201774953<br/>
ফোন : 01716737253<br/>
ঠিকানা : Sujalpur, Birganj, Dinajpur<br/>
জন্মতারিখ : 09-09-1972<br/>   
যোগদানের তারিখ : 19-09-2010<br/>
ইনডেক্স নম্বর : 257426<br /> 
এমপিও কোড  : 08<br/>    
         
এমপিও তারিখ : 01-01-1995<br/>    

প্রথম যোগদান : 03-12-1994(Assit. Teacher)<br/> 
শখ : Reading Newspaper, Internet Browsing.
		</h4>                                                                                                                                              
</div>

</div>


</div>

<div id="bar">

<section class="ac-container">

				<div>
					<input id="ac-1" name="accordion-1" type="checkbox" />
					<label for="ac-1">নোটিশ বোর্ড</label>
					<article class="ac-small">
						<p>Well, the way they make shows is, they make one show. That show's called a pilot. Then they show that show to the people who make shows, and on the strength of that one show they decide if they're going to make more shows.</p>
					</article>
				</div>
				<div>
					<input id="ac-2" name="accordion-1" type="checkbox" />
					<label for="ac-2">ক্লাস রুটিন</label>
					<article class="ac-medium">
						<p>Like you, I used to think the world was this great place where everybody lived by the same standards I did, then some kid with a nail showed me I was living in his world, a world where chaos rules not order, a world where righteousness is not rewarded. That's Cesar's world, and if you're not willing to play by his rules, then you're gonna have to pay the price. </p>
					</article>
				</div>
				<div>
					<input id="ac-3" name="accordion-1" type="checkbox" />
					<label for="ac-3">সিলেবাস</label>
					<article class="ac-large">
						<p>You think water moves fast? You should see ice. It moves like it has a mind. Like it knows it killed the world once and got a taste for murder. After the avalanche, it took us a week to climb out. Now, I don't know exactly when we turned on each other, but I know that seven of us survived the slide... and only five made it out. Now we took an oath, that I'm breaking now. We said we'd say it was the snow that killed the other two, but it wasn't. Nature is lethal but it doesn't hold a candle to man. </p>
					</article>
				</div>
				<div>
					<input id="ac-4" name="accordion-1" type="checkbox" />
					<label for="ac-4">পরীক্ষার রুটিন</label>
					<article class="ac-large">
						<p>You see? It's curious. Ted did figure it out - time travel. And when we get back, we gonna tell everyone. How it's possible, how it's done, what the dangers are. But then why fifty years in the future when the spacecraft encounters a black hole does the computer call it an 'unknown entry event'? Why don't they know? If they don't know, that means we never told anyone. And if we never told anyone it means we never made it back. Hence we die down here. Just as a matter of deductive logic. </p>
					</article>
				</div>

				<div>
					<input id="ac-5" name="accordion-1" type="checkbox" />
					<label for="ac-5">রেজাল্ট</label>
					<article class="ac-large">
						<p><ul type="circle"><li style="margin-left:20px;"><a href="ssc2015.txt">SSC Result 2015</a></li></ul> </p>
					</article>
				</div>
				</section>

<div id="bar1">

<p>গুরুত্বপূর্ণ লিঙ্ক</p>
<br>
<a href="http://www.educationboard.gov.bd"><img src="arrow.png" style="float:left;"><h2 style="float:left;">জাতীয় শিক্ষা বোর্ড</h3></a><br><hr>
<a href="http://www.nctb.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">ই-বুক</h3></a><br><hr>



<a href="http://www.dinajpureducationboard.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">দিনাজপুর শিক্ষা বোর্ড অফিসিয়াল ওয়েবসাইট</h3></a><br><hr>
<a href="http://www.dshe.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">মাধ্যমিক ও উচ্চ শিক্ষা অধিদপ্তর</h3></a><br><hr>
<a href="http://www.moedu.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">শিক্ষা মন্ত্রনালয়</h3></a><br><hr>
<a href="http://www.teachers.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">শিক্ষক বাতায়ন</h3></a><br><hr>


<a href="http://www.dinajpureducationboard.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">দিনাজপুর শিক্ষা বোর্ড</h3></a><br><hr>
<a href="http://mmc.e-service.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">মাল্টিমিডিয়া ক্লাসরুম ম্যানেজমেন্ট সিস্টেম</h3></a><br><hr>
<a href="http://www.nctb.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">জাতীয় শিক্ষাক্রম ও পাঠ্যপুস্তক বোর্ড</h3></a><br><hr>
<a href="http://www.dinajpur.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">জেলা প্রশাসকের কার্যালয়, দিনাজপুর</h3></a><br><hr>




<a href="http://www.bangladesh.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">বাংলাদেশ জাতীয় তথ্য বাতায়ন</h3></a><br><hr>
<a href="http://educationboardresults.gov.bd"><img src="arrow.png" style="float:left;"><h2 style="float:left;">Education Board Result</h3></a><br><hr>
<a href="http://114.130.64.11/esif/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">eSIF</h3></a><br><hr />

<a href="http://eff.teletalk.com.bd/index.php"><img src="arrow.png" style="float:left;"><h2 style="float:left;">eFF</h3></a><br>

</div>

<div id="bar2">

<p>Calender</p>

   <CENTER>

<SCRIPT LANGUAGE="JavaScript">



<!-- Begin
monthnames = new Array(
"January",
"Februrary",
"March",
"April",
"May",
"June",
"July",
"August",
"September",
"October",
"November",
"Decemeber");
var linkcount=0;
function addlink(month, day, href) {
var entry = new Array(3);
entry[0] = month;
entry[1] = day;
entry[2] = href;
this[linkcount++] = entry;
}
Array.prototype.addlink = addlink;
linkdays = new Array();
monthdays = new Array(12);
monthdays[0]=31;
monthdays[1]=28;
monthdays[2]=31;
monthdays[3]=30;
monthdays[4]=31;
monthdays[5]=30;
monthdays[6]=31;
monthdays[7]=31;
monthdays[8]=30;
monthdays[9]=31;
monthdays[10]=30;
monthdays[11]=31;
todayDate=new Date();
thisday=todayDate.getDay();
thismonth=todayDate.getMonth();
thisdate=todayDate.getDate();
thisyear=todayDate.getYear();
thisyear = thisyear % 100;
thisyear = ((thisyear < 50) ? (2000 + thisyear) : (1900 + thisyear));
if (((thisyear % 4 == 0)
&& !(thisyear % 100 == 0))
||(thisyear % 400 == 0)) monthdays[1]++;
startspaces=thisdate;
while (startspaces > 7) startspaces-=7;
startspaces = thisday - startspaces + 1;
if (startspaces < 0) startspaces+=7;
document.write("<table border=2 bgcolor=white ");
document.write("bordercolor=black><font color=black>");
document.write("<tr><td colspan=7><center><strong>"
+ monthnames[thismonth] + " " + thisyear
+ "</strong></center></font></td></tr>");
document.write("<tr>");
document.write("<td align=center>Sun</td>");
document.write("<td align=center>Mon</td>");
document.write("<td align=center>Tue</td>");
document.write("<td align=center>Wed</td>");
document.write("<td align=center>Thu</td>");
document.write("<td align=center>Fri</td>");
document.write("<td align=center>Sat</td>");
document.write("</tr>");
document.write("<tr>");
for (s=0;s<startspaces;s++) {
document.write("<td> </td>");
}
count=1;
while (count <= monthdays[thismonth]) {
for (b = startspaces;b<7;b++) {
linktrue=false;
document.write("<td>");
for (c=0;c<linkdays.length;c++) {
if (linkdays[c] != null) {
if ((linkdays[c][0]==thismonth + 1) && (linkdays[c][1]==count)) {
document.write("<a href=\"" + linkdays[c][2] + "\">");
linktrue=true;
      }
   }
}
if (count==thisdate) {
document.write("<font color='FF0000'><strong>");
}
if (count <= monthdays[thismonth]) {
document.write(count);
}
else {
document.write(" ");
}
if (count==thisdate) {
document.write("</strong></font>");
}
if (linktrue)
document.write("</a>");
document.write("</td>");
count++;
}
document.write("</tr>");
document.write("<tr>");
startspaces=0;
}
document.write("</table></p>");
// End -->
</SCRIPT>
</CENTER>

</div>


<div id="bar3">

<p>Map</p>

<div id="map"></div>

</div>




</div>




<div id="footer">

  <div id="footer1">
  
     <a href="#">যোগাযোগ</a>
	 <a href="#">গ্যালারি</a>
	  <a href="#">বাণী</a>
	   <a href="#">Admin Panel</a>
  
  </div>
  
 
  
  <div id="footer2">
  
  </div>
  
  
  <div id="footer3">
  
    <a href="http://www.facebook.com" target="_blank"><img src="f.png" height="40px" width="40px" /></a>
	 <a href="http://www.tweeter.com" target="_blank"><img src="t.png" height="40px" width="40px" /></a>
	  <a href="http://www.youtube.com"  target="_blank"><img src="y.png" height="40px" width="40px" /></a>
	   <a href="http://www.google.com"  target="_blank"><img src="google.png" height="40px" width="40px" /></a>
	    <a href="http://www.gmail.com.com"  target="_blank"><img src="g.png" height="40px" width="40px" /></a>
  
  
  </div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript" src="http://arrow.scrolltotop.com/arrow7.js"></script>
<noscript>Not seeing a <a href="http://www.scrolltotop.com/">Scroll to Top Button</a>? Go to our FAQ page for more info.</noscript>



  
  </div>

</body>
</html>
