<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <link rel="stylesheet" href="styles.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
<title>Amtoli High School</title>
<link rel="shortcut icon" href="tl.png" type="image/type" />
<link rel="stylesheet" type="text/css" href="style.css" />


<link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
		<script type="text/javascript" src="js/modernizr.custom.29473.js"></script>


 <style>
      #map {
        width: 300px;
        height:200px;
      }
</style>
<script src="https://maps.googleapis.com/maps/api/js"></script>
    <script>
      function initialize() {
        var mapCanvas = document.getElementById('map');
        var mapOptions = {
          center: new google.maps.LatLng(25.8595937,88.6423741),
          zoom: 8,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map(mapCanvas, mapOptions)
      }
      google.maps.event.addDomListener(window, 'load', initialize);
    </script>


</head>

<body>

 
  <div id="container">
  
     <div id="header">
	 
	 </div>
<br>
	 
	<div id='cssmenu'>
<ul>
   <li><a href='index.php'><span>হোম পেজ</span></a></li>
   <li class='has-sub'><a href='#'><span>স্কুল প্রশাসন</span></a>
      <ul>
         <li class='has-sub'><a href='head.php'><span>প্রধান শিক্ষক</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='ahead.php'><span>সহকারী প্রধান শিক্ষক</span></a>
            
         </li>
		 
		  <li class='has-sub'><a href='assit.php'><span>শিক্ষক বৃন্দ</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>শ্রেণি শিক্ষকবৃন্দ</span></a>
           
         </li>
		  
		  
		  <li class='has-sub'><a href='#'><span>কমর্কর্তা-কর্মচারী</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>পিটিএ</span></a>
          
         </li>
       
	   
	     <li class='has-sub'><a href='#'><span>পরিচালনা পরিষদ</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>প্রাক্তন প্রধান শিক্ষকবৃন্দ</span></a>
          
         </li>
       
		 
      </ul>
   </li>
   
   
   
   
   
   
    <li class='has-sub'><a href='#'><span>প্রাতিষ্ঠানিক কার্যক্রম</span></a>
      <ul>
         <li class='has-sub'><a href='#'><span>ক্লাস কার্যক্রম</span></a>
           <ul>
               <li><a href='#'><span>ক্লাস VI</span></a></li>
			    <li><a href='#'><span>ক্লাস VII</span></a></li>
				 <li><a href='#'><span>ক্লাস VIII</span></a></li>
				  <li><a href='#'><span>ক্লাস XI</span></a></li>
				   <li><a href='#'><span>ক্লাস X</span></a></li>
			  
			  
            </ul>
         </li>
		
		  <li class='has-sub'><a href='#'><span>বাৎসরিক কার্যক্রম</span></a>
            
         </li>
		 
		  <li class='has-sub'><a href='#'><span>পাঠ্যক্রম</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>কোর্স সমুহ</span></a>
           
         </li>
		  
		  
		  <li class='has-sub'><a href='#'><span>পরীক্ষার ফল</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>ডকুমেন্টারি</span></a>
          
         </li>
       
	   
	    
       
		 
      </ul>
   </li>
   
   
  
  
  
  
  
  
   <li class='has-sub'><a href='#'><span>অন্যান্য তথ্য</span></a>
      <ul>
         <li class='has-sub'><a href='history.php'><span>স্কুল ইতিহাস</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>নিয়ম কানুন</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>পাঠাগার</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>ছাত্রাবাস</span></a>
           
         </li>
		  
		  
		  <li class='has-sub'><a href='#'><span>প্রয়োজনীয় ডাউনলোড</span></a>
           
         </li>
		 
		 
       
		 
      </ul>
   </li>
   
  
  
 
   
  
  
  
 
  
  
  
   <li class='has-sub'><a href='#'><span>সহপাঠ কাযর্ক্রম</span></a>
      <ul>
         <li class='has-sub'><a href='#'><span>DEBATE CLUB</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>ICT CLUB</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>SCIENCE CLUB</span></a>
           
         </li>
		
		  <li class='has-sub'><a href='#'><span>LANGUAGE CLUB</span></a>
           
         </li>
		  
		  
		  <li class='has-sub'><a href='#'><span>CULTURAL CLUB</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>ENVIRONMENT CLUB</span></a>
          
         </li>
       
	   
	     <li class='has-sub'><a href='#'><span>SCOUTING</span></a>
           
         </li>
		 
		  <li class='has-sub'><a href='#'><span>BNCC</span></a>
          
         </li>
		 
		  <li class='has-sub'><a href='#'><span>অন্যান্য স্কুল কার্যক্রম</span></a>
          
         </li>
       
		 
      </ul>
   </li>
   
   
   
   
  
   
 
  
   
   <li class='last'><a href='#'><span>ভর্তি তথ্য</span></a></li>
   
   <li class='last'><a href='#'><span>রেজাল্ট অনুসন্ধান</span></a></li>
   
  
   
  
</ul>

 
</div>

<div id="mar">
    
<?php



mysql_connect("localhost","amtolihs_sohag","mksbshrmaiu123");
mysql_select_db("amtolihs_admin");

mysql_query('SET CHARACTER SET utf8');
        mysql_query('SET SESSION collation_connection =utf8_general_ci') or die (mysql_error());

$q=mysql_query("Select *from news");

    echo "<marquee onmouseover=\"this.setAttribute('scrollamount', 0, 0);\" onmouseout=\"this.setAttribute('scrollamount', 6, 0);\" style=\"margin-left:80px; margin-top:1px; color:black; letter-spacing:2px;\" >৩১/০১/২০১৬ তারিখে আমতলী উচ্চ বিদ্যালয়ের ওয়েব সাইটটি উদ্বোধন করা হয়েছে। ওয়েব সাইটটির আপগ্রেডের কাজ চলছে।  | ";
    
    
while($row=mysql_fetch_array($q))
{

  
  
 echo $row["news"]."    |  ";
 
  

}

    
    echo "</marquee>"

?>


      
      </div>


<div id="slider">



<script>

+function(f,g,b,j,c,i,k){/*! Jssor */
new(function(){});var e=f.$JssorEasing$={Wc:function(a){return-b.cos(a*b.PI)/2+.5},vd:function(a){return a},yf:function(a){return a*a},wd:function(a){return-a*(a-2)},vf:function(a){return(a*=2)<1?1/2*a*a:-1/2*(--a*(a-2)-1)},Df:function(a){return a*a*a},qf:function(a){return(a-=1)*a*a+1},pf:function(a){return(a*=2)<1?1/2*a*a*a:1/2*((a-=2)*a*a+2)},of:function(a){return a*a*a*a},Me:function(a){return-((a-=1)*a*a*a-1)},He:function(a){return(a*=2)<1?1/2*a*a*a*a:-1/2*((a-=2)*a*a*a-2)},se:function(a){return a*a*a*a*a},le:function(a){return(a-=1)*a*a*a*a+1},te:function(a){return(a*=2)<1?1/2*a*a*a*a*a:1/2*((a-=2)*a*a*a*a+2)},ve:function(a){return 1-b.cos(a*b.PI/2)},we:function(a){return b.sin(a*b.PI/2)},Ee:function(a){return-1/2*(b.cos(b.PI*a)-1)},Be:function(a){return a==0?0:b.pow(2,10*(a-1))},Ae:function(a){return a==1?1:-b.pow(2,-10*a)+1},ze:function(a){return a==0||a==1?a:(a*=2)<1?1/2*b.pow(2,10*(a-1)):1/2*(-b.pow(2,-10*--a)+2)},ye:function(a){return-(b.sqrt(1-a*a)-1)},xe:function(a){return b.sqrt(1-(a-=1)*a)},Ce:function(a){return(a*=2)<1?-1/2*(b.sqrt(1-a*a)-1):1/2*(b.sqrt(1-(a-=2)*a)+1)},Le:function(a){if(!a||a==1)return a;var c=.3,d=.075;return-(b.pow(2,10*(a-=1))*b.sin((a-d)*2*b.PI/c))},he:function(a){if(!a||a==1)return a;var c=.3,d=.075;return b.pow(2,-10*a)*b.sin((a-d)*2*b.PI/c)+1},qe:function(a){if(!a||a==1)return a;var c=.45,d=.1125;return(a*=2)<1?-.5*b.pow(2,10*(a-=1))*b.sin((a-d)*2*b.PI/c):b.pow(2,-10*(a-=1))*b.sin((a-d)*2*b.PI/c)*.5+1},Rf:function(a){var b=1.70158;return a*a*((b+1)*a-b)},Zg:function(a){var b=1.70158;return(a-=1)*a*((b+1)*a+b)+1},Tg:function(a){var b=1.70158;return(a*=2)<1?1/2*a*a*(((b*=1.525)+1)*a-b):1/2*((a-=2)*a*(((b*=1.525)+1)*a+b)+2)},Od:function(a){return 1-e.Ec(1-a)},Ec:function(a){return a<1/2.75?7.5625*a*a:a<2/2.75?7.5625*(a-=1.5/2.75)*a+.75:a<2.5/2.75?7.5625*(a-=2.25/2.75)*a+.9375:7.5625*(a-=2.625/2.75)*a+.984375},Bg:function(a){return a<1/2?e.Od(a*2)*.5:e.Ec(a*2-1)*.5+.5},Cg:function(){return 1-b.abs(1)},Eg:function(a){return 1-b.cos(a*b.PI*2)},Gg:function(a){return b.sin(a*b.PI*2)},Hg:function(a){return 1-((a*=2)<1?(a=1-a)*a*a:(a-=1)*a*a)},Ig:function(a){return(a*=2)<1?a*a*a:(a=2-a)*a*a}},d=f.$Jease$={Ng:e.Wc,Kg:e.vd,Og:e.yf,pb:e.wd,Qc:e.vf,bh:e.Df,ah:e.qf,Vg:e.pf,Rg:e.of,xg:e.Me,Dg:e.He,ag:e.se,Yf:e.le,Xf:e.te,Wf:e.ve,Vf:e.we,cd:e.Ee,Qf:e.Be,Nf:e.Ae,ed:e.ze,Mf:e.ye,Lf:e.xe,Kf:e.Ce,Jf:e.Le,If:e.he,lg:e.qe,sg:e.Rf,rg:e.Zg,pg:e.Tg,ug:e.Od,mg:e.Ec,hg:e.Bg,gg:e.Cg,Gb:e.Eg,Kd:e.Gg,Pd:e.Hg,Jb:e.Ig};f.$JssorDirection$={};var a=f.$Jssor$=new function(){var d=this,Ab=/\S+/g,S=1,tb=2,Z=3,wb=4,db=5,I,s=0,l=0,q=0,J=0,C=0,B=navigator,ib=B.appName,n=B.userAgent;function Jb(){if(!I){I={Re:"ontouchstart"in f||"createTouch"in g};var a;if(B.pointerEnabled||(a=B.msPointerEnabled))I.Yd=a?"msTouchAction":"touchAction"}return I}function t(i){if(!s){s=-1;if(ib=="Microsoft Internet Explorer"&&!!f.attachEvent&&!!f.ActiveXObject){var e=n.indexOf("MSIE");s=S;q=o(n.substring(e+5,n.indexOf(";",e)));/*@cc_on J=@_jscript_version@*/;l=g.documentMode||q}else if(ib=="Netscape"&&!!f.addEventListener){var d=n.indexOf("Firefox"),b=n.indexOf("Safari"),h=n.indexOf("Chrome"),c=n.indexOf("AppleWebKit");if(d>=0){s=tb;l=o(n.substring(d+8))}else if(b>=0){var j=n.substring(0,b).lastIndexOf("/");s=h>=0?wb:Z;l=o(n.substring(j+1,b))}else{var a=/Trident\/.*rv:([0-9]{1,}[\.0-9]{0,})/i.exec(n);if(a){s=S;l=q=o(a[1])}}if(c>=0)C=o(n.substring(c+12))}else{var a=/(opera)(?:.*version|)[ \/]([\w.]+)/i.exec(n);if(a){s=db;l=o(a[2])}}}return i==s}function p(){return t(S)}function N(){return p()&&(l<6||g.compatMode=="BackCompat")}function vb(){return t(Z)}function cb(){return t(db)}function ob(){return vb()&&C>534&&C<535}function L(){return p()&&l<9}function qb(a){var b;return function(d){if(!b){b=a;var c=a.substr(0,1).toUpperCase()+a.substr(1);m([a].concat(["WebKit","ms","Moz","O","webkit"]),function(g,f){var e=a;if(f)e=g+c;if(d.style[e]!=k)return b=e})}return b}}var pb=qb("transform");function hb(a){return{}.toString.call(a)}var H;function Gb(){if(!H){H={};m(["Boolean","Number","String","Function","Array","Date","RegExp","Object"],function(a){H["[object "+a+"]"]=a.toLowerCase()})}return H}function m(a,d){if(hb(a)=="[object Array]"){for(var b=0;b<a.length;b++)if(d(a[b],b,a))return c}else for(var e in a)if(d(a[e],e,a))return c}function z(a){return a==j?String(a):Gb()[hb(a)]||"object"}function fb(a){for(var b in a)return c}function x(a){try{return z(a)=="object"&&!a.nodeType&&a!=a.window&&(!a.constructor||{}.hasOwnProperty.call(a.constructor.prototype,"isPrototypeOf"))}catch(b){}}function w(a,b){return{x:a,y:b}}function lb(b,a){setTimeout(b,a||0)}function F(b,d,c){var a=!b||b=="inherit"?"":b;m(d,function(c){var b=c.exec(a);if(b){var d=a.substr(0,b.index),e=a.substr(b.lastIndex+1,a.length-(b.lastIndex+1));a=d+e}});a=c+(a.indexOf(" ")!=0?" ":"")+a;return a}function sb(b,a){if(l<9)b.style.filter=a}function Cb(g,a,i){if(!J||J<9){var e=a.Ab,f=a.yb,j=(a.z||0)%360,h="";if(j||e!=k||f!=k){if(e==k)e=1;if(f==k)f=1;var c=d.jf(j/180*b.PI,e||1,f||1),i=d.kf(c,a.gb,a.ib);d.wf(g,i.y);d.rf(g,i.x);h="progid:DXImageTransform.Microsoft.Matrix(M11="+c[0][0]+", M12="+c[0][1]+", M21="+c[1][0]+", M22="+c[1][1]+", SizingMethod='auto expand')"}var m=g.style.filter,n=new RegExp(/[\s]*progid:DXImageTransform\.Microsoft\.Matrix\([^\)]*\)/g),l=F(m,[n],h);sb(g,l)}}d.nf=Jb;d.Sd=p;d.re=vb;d.zc=cb;d.jb=L;d.Td=function(){return l};d.Je=function(){t();return C};d.p=lb;function V(a){a.constructor===V.caller&&a.Ud&&a.Ud.apply(a,V.caller.arguments)}d.Ud=V;d.sb=function(a){if(d.be(a))a=g.getElementById(a);return a};function r(a){return a||f.event}d.Vd=r;d.sc=function(a){a=r(a);return a.target||a.srcElement||g};d.ae=function(a){a=r(a);return{x:a.pageX||a.clientX||0,y:a.pageY||a.clientY||0}};function A(c,d,a){if(a!==k)c.style[d]=a==k?"":a;else{var b=c.currentStyle||c.style;a=b[d];if(a==""&&f.getComputedStyle){b=c.ownerDocument.defaultView.getComputedStyle(c,j);b&&(a=b.getPropertyValue(d)||b[d])}return a}}function X(b,c,a,d){if(a!==k){if(a==j)a="";else d&&(a+="px");A(b,c,a)}else return o(A(b,c))}function h(c,a){var d=a?X:A,b;if(a&4)b=qb(c);return function(e,f){return d(e,b?b(e):c,f,a&2)}}function Db(b){if(p()&&q<9){var a=/opacity=([^)]*)/.exec(b.style.filter||"");return a?o(a[1])/100:1}else return o(b.style.opacity||"1")}function Fb(c,a,f){if(p()&&q<9){var h=c.style.filter||"",i=new RegExp(/[\s]*alpha\([^\)]*\)/g),e=b.round(100*a),d="";if(e<100||f)d="alpha(opacity="+e+") ";var g=F(h,[i],d);sb(c,g)}else c.style.opacity=a==1?"":b.round(a*100)/100}var yb={z:["rotate"],Lb:["rotateX"],Kb:["rotateY"],Ab:["scaleX",2],yb:["scaleY",2],Wb:["translateX",1],Vb:["translateY",1],Ub:["translateZ",1],Xb:["skewX"],Tb:["skewY"]};function nb(e,c){if(p()&&l&&l<10){delete c.Lb;delete c.Kb}var d=pb(e);if(d){var b="";a.f(c,function(e,c){var a=yb[c];if(a){var d=a[1]||0;b+=(b?" ":"")+a[0]+"("+e+(["deg","px",""])[d]+")"}});e.style[d]=b}}d.Ag=function(b,a){if(ob())lb(d.N(j,nb,b,a));else(L()?Cb:nb)(b,a)};d.Xd=h("transformOrigin",4);d.Yg=h("backfaceVisibility",4);d.Wg=h("transformStyle",4);d.Qg=h("perspective",6);d.vg=h("perspectiveOrigin",4);d.Sf=function(a,c){if(p()&&q<9||q<10&&N())a.style.zoom=c==1?"":c;else{var b=pb(a);if(b){var f="scale("+c+")",e=a.style[b],g=new RegExp(/[\s]*scale\(.*?\)/g),d=F(e,[g],f);a.style[b]=d}}};var bb=0,ub=0;d.Gf=function(b,a){return L()?function(){var g=c,d=N()?b.document.body:b.document.documentElement;if(d){var f=d.offsetWidth-bb,e=d.offsetHeight-ub;if(f||e){bb+=f;ub+=e}else g=i}g&&a()}:a};d.gc=function(b,a){return function(c){c=r(c);var f=c.type,e=c.relatedTarget||(f=="mouseout"?c.toElement:c.fromElement);(!e||e!==a&&!d.cg(a,e))&&b(c)}};d.g=function(a,e,b,c){a=d.sb(a);if(a.addEventListener){e=="mousewheel"&&a.addEventListener("DOMMouseScroll",b,c);a.addEventListener(e,b,c)}else if(a.attachEvent){a.attachEvent("on"+e,b);c&&a.setCapture&&a.setCapture()}};d.T=function(a,c,e,b){a=d.sb(a);if(a.removeEventListener){c=="mousewheel"&&a.removeEventListener("DOMMouseScroll",e,b);a.removeEventListener(c,e,b)}else if(a.detachEvent){a.detachEvent("on"+c,e);b&&a.releaseCapture&&a.releaseCapture()}};d.Zb=function(a){a=r(a);a.preventDefault&&a.preventDefault();a.cancel=c;a.returnValue=i};d.qg=function(a){a=r(a);a.stopPropagation&&a.stopPropagation();a.cancelBubble=c};d.N=function(d,c){var a=[].slice.call(arguments,2),b=function(){var b=a.concat([].slice.call(arguments,0));return c.apply(d,b)};return b};d.ng=function(a,b){if(b==k)return a.textContent||a.innerText;var c=g.createTextNode(b);d.Tc(a);a.appendChild(c)};d.U=function(d,c){for(var b=[],a=d.firstChild;a;a=a.nextSibling)(c||a.nodeType==1)&&b.push(a);return b};function gb(a,c,e,b){b=b||"u";for(a=a?a.firstChild:j;a;a=a.nextSibling)if(a.nodeType==1){if(R(a,b)==c)return a;if(!e){var d=gb(a,c,e,b);if(d)return d}}}d.G=gb;function P(a,d,f,b){b=b||"u";var c=[];for(a=a?a.firstChild:j;a;a=a.nextSibling)if(a.nodeType==1){R(a,b)==d&&c.push(a);if(!f){var e=P(a,d,f,b);if(e.length)c=c.concat(e)}}return c}function ab(a,c,d){for(a=a?a.firstChild:j;a;a=a.nextSibling)if(a.nodeType==1){if(a.tagName==c)return a;if(!d){var b=ab(a,c,d);if(b)return b}}}d.dg=ab;function rb(a,c,e){var b=[];for(a=a?a.firstChild:j;a;a=a.nextSibling)if(a.nodeType==1){(!c||a.tagName==c)&&b.push(a);if(!e){var d=rb(a,c,e);if(d.length)b=b.concat(d)}}return b}d.eg=rb;d.wg=function(b,a){return b.getElementsByTagName(a)};function y(){var e=arguments,d,c,b,a,g=1&e[0],f=1+g;d=e[f-1]||{};for(;f<e.length;f++)if(c=e[f])for(b in c){a=c[b];if(a!==k){a=c[b];var h=d[b];d[b]=g&&(x(h)||x(a))?y(g,{},h,a):a}}return d}d.r=y;function W(f,g){var d={},c,a,b;for(c in f){a=f[c];b=g[c];if(a!==b){var e;if(x(a)&&x(b)){a=W(a,b);e=!fb(a)}!e&&(d[c]=a)}}return d}d.jd=function(a){return z(a)=="function"};d.Lc=function(a){return z(a)=="array"};d.be=function(a){return z(a)=="string"};d.nc=function(a){return!isNaN(o(a))&&isFinite(a)};d.f=m;d.ig=x;function O(a){return g.createElement(a)}d.vb=function(){return O("DIV")};d.kg=function(){return O("SPAN")};d.id=function(){};function T(b,c,a){if(a==k)return b.getAttribute(c);b.setAttribute(c,a)}function R(a,b){return T(a,b)||T(a,"data-"+b)}d.F=T;d.j=R;function u(b,a){if(a==k)return b.className;b.className=a}d.hd=u;function kb(b){var a={};m(b,function(b){a[b]=b});return a}function mb(b,a){return b.match(a||Ab)}function M(b,a){return kb(mb(b||"",a))}d.og=mb;function Y(b,c){var a="";m(c,function(c){a&&(a+=b);a+=c});return a}function E(a,c,b){u(a,Y(" ",y(W(M(u(a)),M(c)),M(b))))}d.fd=function(a){return a.parentNode};d.V=function(a){d.rb(a,"none")};d.C=function(a,b){d.rb(a,b?"none":"")};d.tg=function(b,a){b.removeAttribute(a)};d.Pf=function(){return p()&&l<10};d.Hf=function(d,c){if(c)d.style.clip="rect("+b.round(c.c)+"px "+b.round(c.u)+"px "+b.round(c.v)+"px "+b.round(c.e)+"px)";else{var g=d.style.cssText,f=[new RegExp(/[\s]*clip: rect\(.*?\)[;]?/i),new RegExp(/[\s]*cliptop: .*?[;]?/i),new RegExp(/[\s]*clipright: .*?[;]?/i),new RegExp(/[\s]*clipbottom: .*?[;]?/i),new RegExp(/[\s]*clipleft: .*?[;]?/i)],e=F(g,f,"");a.lc(d,e)}};d.mb=function(){return+new Date};d.L=function(b,a){b.appendChild(a)};d.kc=function(b,a,c){(c||a.parentNode).insertBefore(b,a)};d.Pb=function(a,b){(b||a.parentNode).removeChild(a)};d.Tf=function(a,b){m(a,function(a){d.Pb(a,b)})};d.Tc=function(a){d.Tf(d.U(a,c),a)};d.Uf=function(a,b){var c=d.fd(a);b&1&&d.K(a,(d.k(c)-d.k(a))/2);b&2&&d.I(a,(d.m(c)-d.m(a))/2)};d.jc=function(b,a){return parseInt(b,a||10)};var o=parseFloat;d.tc=o;d.cg=function(b,a){var c=g.body;while(a&&b!==a&&c!==a)try{a=a.parentNode}catch(d){return i}return b===a};function U(e,c,b){var a=e.cloneNode(!c);!b&&d.tg(a,"id");return a}d.kb=U;d.Rb=function(f,g){var a=new Image;function b(f,c){d.T(a,"load",b);d.T(a,"abort",e);d.T(a,"error",e);g&&g(a,c)}function e(a){b(a,c)}if(cb()&&l<11.6||!f)b(!f);else{d.g(a,"load",b);d.g(a,"abort",e);d.g(a,"error",e);a.src=f}};d.Pg=function(e,a,f){var c=e.length+1;function b(b){c--;if(a&&b&&b.src==a.src)a=b;!c&&f&&f(a)}m(e,function(a){d.Rb(a.src,b)});b()};d.bd=function(b,g,i,h){if(h)b=U(b);var c=P(b,g);if(!c.length)c=a.wg(b,g);for(var f=c.length-1;f>-1;f--){var d=c[f],e=U(i);u(e,u(d));a.lc(e,d.style.cssText);a.kc(e,d);a.Pb(d)}return b};function Hb(b){var l=this,p="",r=["av","pv","ds","dn"],f=[],q,j=0,h=0,e=0;function i(){E(b,q,f[e||j||h&2||h]);a.lb(b,"pointer-events",e?"none":"")}function c(){j=0;i();d.T(g,"mouseup",c);d.T(g,"touchend",c);d.T(g,"touchcancel",c)}function o(a){if(e)d.Zb(a);else{j=4;i();d.g(g,"mouseup",c);d.g(g,"touchend",c);d.g(g,"touchcancel",c)}}l.Qd=function(a){if(a===k)return h;h=a&2||a&1;i()};l.kd=function(a){if(a===k)return!e;e=a?0:3;i()};l.O=b=d.sb(b);var n=a.og(u(b));if(n)p=n.shift();m(r,function(a){f.push(p+a)});q=Y(" ",f);f.unshift("");d.g(b,"mousedown",o);d.g(b,"touchstart",o)}d.ic=function(a){return new Hb(a)};d.lb=A;d.zb=h("overflow");d.I=h("top",2);d.K=h("left",2);d.k=h("width",2);d.m=h("height",2);d.rf=h("marginLeft",2);d.wf=h("marginTop",2);d.D=h("position");d.rb=h("display");d.J=h("zIndex",1);d.Mb=function(b,a,c){if(a!=k)Fb(b,a,c);else return Db(b)};d.lc=function(a,b){if(b!=k)a.style.cssText=b;else return a.style.cssText};var Q={s:d.Mb,c:d.I,e:d.K,X:d.k,Y:d.m,Sb:d.D,Z:d.J},K;function G(){if(!K)K=y({a:d.Hf,E:d.Ag},Q);return K}function eb(){var a={};a.E=a.E;a.E=a.z;a.E=a.Lb;a.E=a.Kb;a.E=a.Xb;a.E=a.Tb;a.E=a.Wb;a.E=a.Vb;a.E=a.Ub;return G()}d.zg=G;d.ld=eb;d.Xg=function(c,b){G();var a={};m(b,function(d,b){if(Q[b])a[b]=Q[b](c)});return a};d.nb=function(c,b){var a=G();m(b,function(d,b){a[b]&&a[b](c,d)})};d.Lg=function(b,a){eb();d.nb(b,a)};var D=new function(){var a=this;function b(d,g){for(var j=d[0].length,i=d.length,h=g[0].length,f=[],c=0;c<i;c++)for(var k=f[c]=[],b=0;b<h;b++){for(var e=0,a=0;a<j;a++)e+=d[c][a]*g[a][b];k[b]=e}return f}a.Ab=function(b,c){return a.nd(b,c,0)};a.yb=function(b,c){return a.nd(b,0,c)};a.nd=function(a,c,d){return b(a,[[c,0],[0,d]])};a.hc=function(d,c){var a=b(d,[[c.x],[c.y]]);return w(a[0][0],a[1][0])}};d.jf=function(d,a,c){var e=b.cos(d),f=b.sin(d);return[[e*a,-f*c],[f*a,e*c]]};d.kf=function(d,c,a){var e=D.hc(d,w(-c/2,-a/2)),f=D.hc(d,w(c/2,-a/2)),g=D.hc(d,w(c/2,a/2)),h=D.hc(d,w(-c/2,a/2));return w(b.min(e.x,f.x,g.x,h.x)+c/2,b.min(e.y,f.y,g.y,h.y)+a/2)};var zb={l:1,Ab:1,yb:1,z:0,Lb:0,Kb:0,Wb:0,Vb:0,Ub:0,Xb:0,Tb:0};d.Bc=function(b){var c=b||{};if(b)if(a.jd(b))c={Bb:c};else if(a.jd(b.a))c.a={Bb:b.a};return c};function jb(c,a){var b={};m(c,function(c,e){var f=c;if(a[e]!=k)if(d.nc(c))f=c+a[e];else f=jb(c,a[e]);b[e]=f});return b}d.Ef=jb;d.Nd=function(h,i,w,n,y,z,o){var c=i;if(h){c={};for(var g in i){var A=z[g]||1,v=y[g]||[0,1],d=(w-v[0])/v[1];d=b.min(b.max(d,0),1);d=d*A;var u=b.floor(d);if(d!=u)d-=u;var l=n.Bb||e.Wc,m,B=h[g],q=i[g];if(a.nc(q)){l=n[g]||l;var x=l(d);m=B+q*x}else{m=a.r({Ob:{}},h[g]);a.f(q.Ob||q,function(e,a){if(n.a)l=n.a[a]||n.a.Bb||l;var c=l(d),b=e*c;m.Ob[a]=b;m[a]+=b})}c[g]=m}var t,f={gb:o.gb,ib:o.ib};a.f(zb,function(d,a){t=t||i[a];var b=c[a];if(b!=k){if(b!=d)f[a]=b;delete c[a]}else if(h[a]!=k&&h[a]!=d)f[a]=h[a]});if(i.l&&f.l){f.Ab=f.l;f.yb=f.l}c.E=f}if(i.a&&o.db){var p=c.a.Ob,s=(p.c||0)+(p.v||0),r=(p.e||0)+(p.u||0);c.e=(c.e||0)+r;c.c=(c.c||0)+s;c.a.e-=r;c.a.u-=r;c.a.c-=s;c.a.v-=s}if(c.a&&a.Pf()&&!c.a.c&&!c.a.e&&c.a.u==o.gb&&c.a.v==o.ib)c.a=j;return c}};function n(){var b=this,d=[];function i(a,b){d.push({Xc:a,Sc:b})}function h(b,c){a.f(d,function(a,e){a.Xc==b&&a.Sc===c&&d.splice(e,1)})}b.Eb=b.addEventListener=i;b.removeEventListener=h;b.o=function(b){var c=[].slice.call(arguments,1);a.f(d,function(a){a.Xc==b&&a.Sc.apply(f,c)})}}var l=f.$JssorAnimator$=function(y,C,k,O,L,K){y=y||0;var d=this,q,n,o,u,z=0,G,H,F,B,x=0,h=0,m=0,D,l,g,e,p,w=[],A;function N(a){g+=a;e+=a;l+=a;h+=a;m+=a;x+=a}function t(n){var f=n;if(p&&(f>=e||f<=g))f=((f-g)%p+p)%p+g;if(!D||u||h!=f){var i=b.min(f,e);i=b.max(i,g);if(!D||u||i!=m){if(K){var j=(i-l)/(C||1);if(k.fc)j=1-j;var o=a.Nd(L,K,j,G,F,H,k);a.f(o,function(b,a){A[a]&&A[a](O,b)})}d.wc(m-l,i-l);m=i;a.f(w,function(b,c){var a=n<h?w[w.length-c-1]:b;a.B(m-x)});var r=h,q=m;h=f;D=c;d.ec(r,q)}}}function E(a,c,d){c&&a.S(e);if(!d){g=b.min(g,a.vc()+x);e=b.max(e,a.cb()+x)}w.push(a)}var r=f.requestAnimationFrame||f.webkitRequestAnimationFrame||f.mozRequestAnimationFrame||f.msRequestAnimationFrame;if(a.re()&&a.Td()<7)r=j;r=r||function(b){a.p(b,k.ob)};function I(){if(q){var d=a.mb(),e=b.min(d-z,k.Jd),c=h+e*o;z=d;if(c*o>=n*o)c=n;t(c);if(!u&&c*o>=n*o)J(B);else r(I)}}function s(f,i,j){if(!q){q=c;u=j;B=i;f=b.max(f,g);f=b.min(f,e);n=f;o=n<h?-1:1;d.Id();z=a.mb();r(I)}}function J(a){if(q){u=q=B=i;d.Hd();a&&a()}}d.Fd=function(a,b,c){s(a?h+a:e,b,c)};d.Ed=s;d.qb=J;d.De=function(a){s(a)};d.bb=function(){return h};d.Cd=function(){return n};d.Ib=function(){return m};d.B=t;d.db=function(a){t(h+a)};d.Ad=function(){return q};d.ke=function(a){p=a};d.S=N;d.M=function(a,b){E(a,0,b)};d.yc=function(a){E(a,1)};d.ne=function(a){e+=a};d.vc=function(){return g};d.cb=function(){return e};d.ec=d.Id=d.Hd=d.wc=a.id;d.Ac=a.mb();k=a.r({ob:16,Jd:50},k);p=k.zd;A=a.r({},a.zg(),k.Cc);g=l=y;e=y+C;H=k.H||{};F=k.R||{};G=a.Bc(k.n)};var m=f.$JssorSlideshowFormations$=new function(){var h=this,t=1,q=2,r=4,s=8,w=256,x=512,v=1024,u=2048,j=u+t,i=u+q,o=x+t,m=x+q,n=w+r,k=w+s,l=v+r,p=v+s;function y(a){return(a&q)==q}function z(a){return(a&r)==r}function g(b,a,c){c.push(a);b[a]=b[a]||[];b[a].push(c)}h.Fc=function(f){for(var d=f.i,e=f.q,s=f.W,t=f.xd,r=[],a=0,b=0,p=d-1,q=e-1,h=t-1,c,b=0;b<e;b++)for(a=0;a<d;a++){switch(s){case j:c=h-(a*e+(q-b));break;case l:c=h-(b*d+(p-a));break;case o:c=h-(a*e+b);case n:c=h-(b*d+a);break;case i:c=a*e+b;break;case k:c=b*d+(p-a);break;case m:c=a*e+(q-b);break;default:c=b*d+a}g(r,c,[b,a])}return r};h.Nb=function(q){var u=q.i,v=q.q,e=q.W,t=q.xd,r=[],s=0,c=0,d=0,f=u-1,h=v-1,w=t-1;switch(e){case j:case m:case o:case i:var a=0,b=0;break;case k:case l:case n:case p:var a=f,b=0;break;default:e=p;var a=f,b=0}c=a;d=b;while(s<t){if(z(e)||y(e))g(r,w-s++,[d,c]);else g(r,s++,[d,c]);switch(e){case j:case m:c--;d++;break;case o:case i:c++;d--;break;case k:case l:c--;d--;break;case p:case n:default:c++;d++}if(c<0||d<0||c>f||d>h){switch(e){case j:case m:a++;break;case k:case l:case o:case i:b++;break;case p:case n:default:a--}if(a<0||b<0||a>f||b>h){switch(e){case j:case m:a=f;b++;break;case o:case i:b=h;a++;break;case k:case l:b=h;a--;break;case p:case n:default:a=0;b++}if(b>h)b=h;else if(b<0)b=0;else if(a>f)a=f;else if(a<0)a=0}d=b;c=a}}return r};h.xf=function(d){for(var e=[],a,c=0;c<d.q;c++)for(a=0;a<d.i;a++)g(e,b.ceil(1e5*b.random())%13,[c,a]);return e}},r=f.$JssorSlideshowRunner$=function(o,s,q,t,y){var f=this,u,g,d,x=0,w=t.Af,r,h=8;function k(g,f){var d={ob:f,A:1,p:0,i:1,q:1,s:0,l:0,a:0,db:i,Q:i,fc:i,P:m.xf,W:1032,Vc:{td:0,gf:0},n:e.Wc,H:{},dc:[],R:{}};a.r(d,g);d.xd=d.i*d.q;d.n=a.Bc(d.n);d.Pe=b.ceil(d.A/d.ob);d.Qe=function(b,a){b/=d.i;a/=d.q;var f=b+"x"+a;if(!d.dc[f]){d.dc[f]={X:b,Y:a};for(var c=0;c<d.i;c++)for(var e=0;e<d.q;e++)d.dc[f][e+","+c]={c:e*a,u:c*b+b,v:e*a+a,e:c*b}}return d.dc[f]};if(d.Rc){d.Rc=k(d.Rc,f);d.Q=c}return d}function p(A,h,d,v,n,l){var y=this,t,u={},j={},m=[],f,e,r,p=d.Vc.td||0,q=d.Vc.gf||0,g=d.Qe(n,l),o=B(d),C=o.length-1,s=d.A+d.p*C,w=v+s,k=d.Q,x;w+=50;function B(a){var b=a.P(a);return a.fc?b.reverse():b}y.rd=w;y.cc=function(c){c-=v;var e=c<s;if(e||x){x=e;if(!k)c=s-c;var f=b.ceil(c/d.ob);a.f(j,function(c,e){var d=b.max(f,c.Se);d=b.min(d,c.length-1);if(c.qd!=d){if(!c.qd&&!k)a.C(m[e]);else d==c.Te&&k&&a.V(m[e]);c.qd=d;a.Lg(m[e],c[d])}})}};h=a.kb(h);if(a.jb()){var D=!h["no-image"],z=a.eg(h);a.f(z,function(b){(D||b["jssor-slider"])&&a.Mb(b,a.Mb(b),c)})}a.f(o,function(h,m){a.f(h,function(G){var K=G[0],J=G[1],v=K+","+J,o=i,s=i,x=i;if(p&&J%2){if(p&3)o=!o;if(p&12)s=!s;if(p&16)x=!x}if(q&&K%2){if(q&3)o=!o;if(q&12)s=!s;if(q&16)x=!x}d.c=d.c||d.a&4;d.v=d.v||d.a&8;d.e=d.e||d.a&1;d.u=d.u||d.a&2;var E=s?d.v:d.c,B=s?d.c:d.v,D=o?d.u:d.e,C=o?d.e:d.u;d.a=E||B||D||C;r={};e={c:0,e:0,s:1,X:n,Y:l};f=a.r({},e);t=a.r({},g[v]);if(d.s)e.s=2-d.s;if(d.Z){e.Z=d.Z;f.Z=0}var I=d.i*d.q>1||d.a;if(d.l||d.z){var H=c;if(a.jb())if(d.i*d.q>1)H=i;else I=i;if(H){e.l=d.l?d.l-1:1;f.l=1;if(a.jb()||a.zc())e.l=b.min(e.l,2);var N=d.z||0;e.z=N*360*(x?-1:1);f.z=0}}if(I){var h=t.Ob={};if(d.a){var w=d.Ue||1;if(E&&B){h.c=g.Y/2*w;h.v=-h.c}else if(E)h.v=-g.Y*w;else if(B)h.c=g.Y*w;if(D&&C){h.e=g.X/2*w;h.u=-h.e}else if(D)h.u=-g.X*w;else if(C)h.e=g.X*w}r.a=t;f.a=g[v]}var L=o?1:-1,M=s?1:-1;if(d.x)e.e+=n*d.x*L;if(d.y)e.c+=l*d.y*M;a.f(e,function(b,c){if(a.nc(b))if(b!=f[c])r[c]=b-f[c]});u[v]=k?f:e;var F=d.Pe,A=b.round(m*d.p/d.ob);j[v]=new Array(A);j[v].Se=A;j[v].Te=A+F-1;for(var z=0;z<=F;z++){var y=a.Nd(f,r,z/F,d.n,d.R,d.H,{db:d.db,gb:n,ib:l});y.Z=y.Z||1;j[v].push(y)}})});o.reverse();a.f(o,function(b){a.f(b,function(c){var f=c[0],e=c[1],d=f+","+e,b=h;if(e||f)b=a.kb(h);a.nb(b,u[d]);a.zb(b,"hidden");a.D(b,"absolute");A.Ve(b);m[d]=b;a.C(b,!k)})})}function v(){var a=this,b=0;l.call(a,0,u);a.ec=function(c,a){if(a-b>h){b=a;d&&d.cc(a);g&&g.cc(a)}};a.fb=r}f.We=function(){var a=0,c=t.eb,d=c.length;if(w)a=x++%d;else a=b.floor(b.random()*d);c[a]&&(c[a].wb=a);return c[a]};f.Xe=function(w,x,j,l,a){r=a;a=k(a,h);var i=l.od,e=j.od;i["no-image"]=!l.bc;e["no-image"]=!j.bc;var m=i,n=e,v=a,c=a.Rc||k({},h);if(!a.Q){m=e;n=i}var t=c.S||0;g=new p(o,n,c,b.max(t-c.ob,0),s,q);d=new p(o,m,v,b.max(c.ob-t,0),s,q);g.cc(0);d.cc(0);u=b.max(g.rd,d.rd);f.wb=w};f.Db=function(){o.Db();g=j;d=j};f.Ye=function(){var a=j;if(d)a=new v;return a};if(a.jb()||a.zc()||y&&a.Je()<537)h=16;n.call(f);l.call(f,-1e7,1e7)},h=f.$JssorSlider$=function(q,cc){var m=this;function yc(){var a=this;l.call(a,-1e8,2e8);a.af=function(){var c=a.Ib(),d=b.floor(c),f=t(d),e=c-b.floor(c);return{wb:f,bf:d,Sb:e}};a.ec=function(d,a){var e=b.floor(a);if(e!=a&&a>d)e++;Rb(e,c);m.o(h.cf,t(a),t(d),a,d)}}function xc(){var b=this;l.call(b,0,0,{zd:r});a.f(C,function(a){D&1&&a.ke(r);b.yc(a);a.S(ib/Yb)})}function wc(){var a=this,b=Tb.O;l.call(a,-1,2,{n:e.vd,Cc:{Sb:Xb},zd:r},b,{Sb:1},{Sb:-2});a.ac=b}function jc(o,n){var a=this,e,f,g,k,b;l.call(a,-1e8,2e8,{Jd:100});a.Id=function(){M=c;S=j;m.o(h.ef,t(w.bb()),w.bb())};a.Hd=function(){M=i;k=i;var a=w.af();m.o(h.ff,t(w.bb()),w.bb());!a.Sb&&Ac(a.bf,s)};a.ec=function(i,h){var a;if(k)a=b;else{a=f;if(g){var c=h/g;a=d.fg(c)*(f-e)+e}}w.B(a)};a.qc=function(b,d,c,h){e=b;f=d;g=c;w.B(b);a.B(0);a.Ed(c,h)};a.Ze=function(d){k=c;b=d;a.Fd(d,j,c)};a.zf=function(a){b=a};w=new yc;w.M(o);w.M(n)}function lc(){var c=this,b=Vb();a.J(b,0);a.lb(b,"pointerEvents","none");c.O=b;c.Ve=function(c){a.L(b,c);a.C(b)};c.Db=function(){a.V(b);a.Tc(b)}}function vc(o,f){var e=this,q,L,v,k,y=[],x,B,W,G,Q,F,g,w,p;l.call(e,-u,u+1,{});function E(b){q&&q.xb();T(o,b,0);F=c;q=new I.ab(o,I,a.tc(a.j(o,"idle"))||ic);q.B(0)}function Z(){q.Ac<I.Ac&&E()}function M(p,r,o){if(!G){G=c;if(k&&o){var g=o.width,b=o.height,n=g,l=b;if(g&&b&&d.Qb){if(d.Qb&3&&(!(d.Qb&4)||g>K||b>J)){var j=i,q=K/J*b/g;if(d.Qb&1)j=q>1;else if(d.Qb&2)j=q<1;n=j?g*J/b:K;l=j?J:b*K/g}a.k(k,n);a.m(k,l);a.I(k,(J-l)/2);a.K(k,(K-n)/2)}a.D(k,"absolute");m.o(h.uf,f)}}a.V(r);p&&p(e)}function Y(b,c,d,g){if(g==S&&s==f&&N)if(!zc){var a=t(b);A.Xe(a,f,c,e,d);c.sf();U.S(a-U.vc()-1);U.B(a);z.qc(b,b,0)}}function cb(b){if(b==S&&s==f){if(!g){var a=j;if(A)if(A.wb==f)a=A.Ye();else A.Db();Z();g=new sc(o,f,a,q);g.yd(p)}!g.Ad()&&g.Dc()}}function R(c,h,l){if(c==f){if(c!=h)C[h]&&C[h].Oe();else!l&&g&&g.tf();p&&p.kd();var m=S=a.mb();e.Rb(a.N(j,cb,m))}else{var k=b.min(f,c),i=b.max(f,c),o=b.min(i-k,k+r-i),n=u+d.pe-1;(!Q||o<=n)&&e.Rb()}}function db(){if(s==f&&g){g.qb();p&&p.oe();p&&p.je();g.Bd()}}function eb(){s==f&&g&&g.qb()}function ab(a){!P&&m.o(h.ge,f,a)}function O(){p=w.pInstance;g&&g.yd(p)}e.Rb=function(d,b){b=b||v;if(y.length&&!G){a.C(b);if(!W){W=c;m.o(h.fe,f);a.f(y,function(b){if(!a.F(b,"src")){b.src=a.j(b,"src2");a.rb(b,b["display-origin"])}})}a.Pg(y,k,a.N(j,M,d,b))}else M(d,b)};e.ee=function(){var h=f;if(d.Dd<0)h-=r;var c=h+d.Dd*qc;if(D&2)c=t(c);if(!(D&1))c=b.max(0,b.min(c,r-u));if(c!=f){if(A){var e=A.We(r);if(e){var i=S=a.mb(),g=C[t(c)];return g.Rb(a.N(j,Y,c,g,e,i),v)}}bb(c)}};e.uc=function(){R(f,f,c)};e.Oe=function(){p&&p.oe();p&&p.je();e.Ld();g&&g.ue();g=j;E()};e.sf=function(){a.V(o)};e.Ld=function(){a.C(o)};e.Fe=function(){p&&p.kd()};function T(b,d,e){if(a.F(b,"jssor-slider"))return;if(!F){if(b.tagName=="IMG"){y.push(b);if(!a.F(b,"src")){Q=c;b["display-origin"]=a.rb(b);a.V(b)}}a.jb()&&a.J(b,(a.J(b)||0)+1)}var f=a.U(b);a.f(f,function(f){var h=f.tagName,j=a.j(f,"u");if(j=="player"&&!w){w=f;if(w.pInstance)O();else a.g(w,"dataavailable",O)}if(j=="caption"){if(d){a.Xd(f,a.j(f,"to"));a.Yg(f,a.j(f,"bf"));a.Wg(f,"preserve-3d")}else if(!a.Sd()){var g=a.kb(f,i,c);a.kc(g,f,b);a.Pb(f,b);f=g;d=c}}else if(!F&&!e&&!k){if(h=="A"){if(a.j(f,"u")=="image")k=a.dg(f,"IMG");else k=a.G(f,"image",c);if(k){x=f;a.rb(x,"block");a.nb(x,V);B=a.kb(x,c);a.D(x,"relative");a.Mb(B,0);a.lb(B,"backgroundColor","#000")}}else if(h=="IMG"&&a.j(f,"u")=="image")k=f;if(k){k.border=0;a.nb(k,V)}}T(f,d,e+1)})}e.wc=function(c,b){var a=u-b;Xb(L,a)};e.wb=f;n.call(e);a.Qg(o,a.j(o,"p"));a.vg(o,a.j(o,"po"));var H=a.G(o,"thumb",c);if(H){e.Ge=a.kb(H);a.V(H)}a.C(o);v=a.kb(fb);a.J(v,1e3);a.g(o,"click",ab);E(c);e.bc=k;e.Md=B;e.od=o;e.ac=L=o;a.L(L,v);m.Eb(203,R);m.Eb(28,eb);m.Eb(24,db)}function sc(y,f,p,q){var b=this,n=0,u=0,g,j,e,d,k,t,r,o=C[f];l.call(b,0,0);function v(){a.Tc(L);Zb&&k&&o.Md&&a.L(L,o.Md);a.C(L,!k&&o.bc)}function w(){b.Dc()}function x(a){r=a;b.qb();b.Dc()}b.Dc=function(){var a=b.Ib();if(!B&&!M&&!r&&s==f){if(!a){if(g&&!k){k=c;b.Bd(c);m.o(h.Ie,f,n,u,g,d)}v()}var i,p=h.Yc;if(a!=d)if(a==e)i=d;else if(a==j)i=e;else if(!a)i=j;else i=b.Cd();m.o(p,f,a,n,j,e,d);var l=N&&(!E||F);if(a==d)(e!=d&&!(E&12)||l)&&o.ee();else(l||a!=e)&&b.Ed(i,w)}};b.tf=function(){e==d&&e==b.Ib()&&b.B(j)};b.ue=function(){A&&A.wb==f&&A.Db();var a=b.Ib();a<d&&m.o(h.Yc,f,-a-1,n,j,e,d)};b.Bd=function(b){p&&a.zb(jb,b&&p.fb.ub?"":"hidden")};b.wc=function(b,a){if(k&&a>=g){k=i;v();o.Ld();A.Db();m.o(h.Fg,f,n,u,g,d)}m.o(h.Jg,f,a,n,j,e,d)};b.yd=function(a){if(a&&!t){t=a;a.Eb($JssorPlayer$.lf,x)}};p&&b.yc(p);g=b.cb();b.yc(q);j=g+q.Yb;e=g+q.oc;d=b.cb()}function Xb(g,f){var e=x>0?x:eb,c=zb*f*(e&1),d=Ab*f*(e>>1&1);c=b.round(c);d=b.round(d);a.K(g,c);a.I(g,d)}function Nb(){pb=M;Ib=z.Cd();G=w.bb()}function ec(){Nb();if(B||!F&&E&12){z.qb();m.o(h.Ug)}}function bc(f){if(!B&&(F||!(E&12))&&!z.Ad()){var c=w.bb(),a=b.ceil(G);if(f&&b.abs(H)>=d.dd){a=b.ceil(c);a+=hb}if(!(D&1))a=b.min(r-u,b.max(a,0));var e=b.abs(a-c);e=1-b.pow(1-e,5);if(!P&&pb)z.De(Ib);else if(c==a){sb.Fe();sb.uc()}else z.qc(c,a,e*Sb)}}function Hb(b){!a.j(a.sc(b),"nodrag")&&a.Zb(b)}function oc(a){Wb(a,1)}function Wb(b,d){b=a.Vd(b);var k=a.sc(b);if(!O&&!a.j(k,"nodrag")&&pc()&&(!d||b.touches.length==1)){B=c;yb=i;S=j;a.g(g,d?"touchmove":"mousemove",Bb);a.mb();P=0;ec();if(!pb)x=0;if(d){var f=b.touches[0];ub=f.clientX;vb=f.clientY}else{var e=a.ae(b);ub=e.x;vb=e.y}H=0;gb=0;hb=0;m.o(h.Zf,t(G),G,b)}}function Bb(e){if(B){e=a.Vd(e);var f;if(e.type!="mousemove"){var l=e.touches[0];f={x:l.clientX,y:l.clientY}}else f=a.ae(e);if(f){var j=f.x-ub,k=f.y-vb;if(b.floor(G)!=G)x=x||eb&O;if((j||k)&&!x){if(O==3)if(b.abs(k)>b.abs(j))x=2;else x=1;else x=O;if(mb&&x==1&&b.abs(k)-b.abs(j)>3)yb=c}if(x){var d=k,i=Ab;if(x==1){d=j;i=zb}if(!(D&1)){if(d>0){var g=i*s,h=d-g;if(h>0)d=g+b.sqrt(h)*5}if(d<0){var g=i*(r-u-s),h=-d-g;if(h>0)d=-g-b.sqrt(h)*5}}if(H-gb<-2)hb=0;else if(H-gb>2)hb=-1;gb=H;H=d;rb=G-H/i/(Y||1);if(H&&x&&!yb){a.Zb(e);if(!M)z.Ze(rb);else z.zf(rb)}}}}}function ab(){nc();if(B){B=i;a.mb();a.T(g,"mousemove",Bb);a.T(g,"touchmove",Bb);P=H;z.qb();var b=w.bb();m.o(h.Of,t(b),b,t(G),G);E&12&&Nb();bc(c)}}function fc(c){if(P){a.qg(c);var b=a.sc(c);while(b&&v!==b){b.tagName=="A"&&a.Zb(c);try{b=b.parentNode}catch(d){break}}}}function hc(a){C[s];s=t(a);sb=C[s];Rb(a);return s}function Ac(a,b){x=0;hc(a);m.o(h.bg,t(a),b)}function Rb(b,c){wb=b;a.f(T,function(a){a.xc(t(b),b,c)})}function pc(){var b=h.ad||0,a=X;if(mb)a&1&&(a&=1);h.ad|=a;return O=a&~b}function nc(){if(O){h.ad&=~X;O=0}}function Vb(){var b=a.vb();a.nb(b,V);a.D(b,"absolute");return b}function t(a){return(a%r+r)%r}function gc(a,c){if(c)if(!D){a=b.min(b.max(a+wb,0),r-u);c=i}else if(D&2){a=t(a+wb);c=i}bb(a,d.Gc,c)}function xb(){a.f(T,function(a){a.Pc(a.mc.hh<=F)})}function Cc(){if(!F){F=1;xb();if(!B){E&12&&bc();E&3&&C[s].uc()}}}function Bc(){if(F){F=0;xb();B||!(E&12)||ec()}}function Dc(){V={X:K,Y:J,c:0,e:0};a.f(Q,function(b){a.nb(b,V);a.D(b,"absolute");a.zb(b,"hidden");a.V(b)});a.nb(fb,V)}function ob(b,a){bb(b,a,c)}function bb(g,f,l){if(Pb&&(!B&&(F||!(E&12))||d.gd)){M=c;B=i;z.qb();if(f==k)f=Sb;var e=Cb.Ib(),a=g;if(l){a=e+g;if(g>0)a=b.ceil(a);else a=b.floor(a)}if(D&2)a=t(a);if(!(D&1))a=b.max(0,b.min(a,r-u));var j=(a-e)%r;a=e+j;var h=e==a?0:f*b.abs(j);h=b.min(h,f*u*1.5);z.qc(e,a,h||1)}}m.jg=bb;m.Fd=function(){if(!N){N=c;C[s]&&C[s].uc()}};m.Ff=function(){return P};function W(){return a.k(y||q)}function lb(){return a.m(y||q)}m.gb=W;m.ib=lb;function Eb(c,d){if(c==k)return a.k(q);if(!y){var b=a.vb(g);a.hd(b,a.hd(q));a.lc(b,a.lc(q));a.rb(b,"block");a.D(b,"relative");a.I(b,0);a.K(b,0);a.zb(b,"visible");y=a.vb(g);a.D(y,"absolute");a.I(y,0);a.K(y,0);a.k(y,a.k(q));a.m(y,a.m(q));a.Xd(y,"0 0");a.L(y,b);var h=a.U(q);a.L(q,y);a.lb(q,"backgroundImage","");a.f(h,function(c){a.L(a.j(c,"noscale")?q:b,c);a.j(c,"autocenter")&&Jb.push(c)})}Y=c/(d?a.m:a.k)(y);a.Sf(y,Y);var f=d?Y*W():c,e=d?c:Y*lb();a.k(q,f);a.m(q,e);a.f(Jb,function(b){var c=a.jc(a.j(b,"autocenter"));a.Uf(b,c)})}m.me=Eb;m.Rd=function(a){var d=b.ceil(t(ib/Yb)),c=t(a-s+d);if(c>u){if(a-s>r/2)a-=r;else if(a-s<=-r/2)a+=r}else a=s+c-d;return a};n.call(m);m.O=q=a.sb(q);var d=a.r({Qb:0,pe:1,Ic:1,Oc:0,Nc:i,pc:1,gd:c,Dd:1,Zd:3e3,ce:1,Gc:500,fg:e.wd,dd:20,de:0,i:1,md:0,Sg:1,Mc:1,Wd:1},cc);if(d.hf!=k)d.Zd=d.hf;if(d.Uc!=k)d.i=d.Uc;if(d.Cf!=k)d.md=d.Cf;var eb=d.Mc&3,qc=(d.Mc&4)/-4||1,kb=d.Ne,I=a.r({ab:p,Bf:1,ie:1},d.fh);I.eb=I.eb||I.gh;var Fb=d.Ke,Z=d.mf,db=d.ih,R=!d.Sg,y,v=a.G(q,"slides",R),fb=a.G(q,"loading",R)||a.vb(g),Lb=a.G(q,"navigator",R),dc=a.G(q,"arrowleft",R),ac=a.G(q,"arrowright",R),Kb=a.G(q,"thumbnavigator",R),mc=a.k(v),kc=a.m(v),V,Q=[],rc=a.U(v);a.f(rc,function(b){if(b.tagName=="DIV"&&!a.j(b,"u"))Q.push(b);else a.jb()&&a.J(b,(a.J(b)||0)+1)});var s=-1,wb,sb,r=Q.length,K=d.Mg||mc,J=d.yg||kc,Ub=d.de,zb=K+Ub,Ab=J+Ub,Yb=eb&1?zb:Ab,u=b.min(d.i,r),jb,x,O,yb,T=[],Ob,Qb,Mb,Zb,zc,N,E=d.ce,ic=d.Zd,Sb=d.Gc,qb,tb,ib,Pb=u<r,D=Pb?d.pc:0,X,P,F=1,M,B,S,ub=0,vb=0,H,gb,hb,Cb,w,U,z,Tb=new lc,Y,Jb=[];N=d.Nc;m.mc=cc;Dc();a.F(q,"jssor-slider",c);a.J(v,a.J(v)||0);a.D(v,"absolute");jb=a.kb(v,c);a.kc(jb,v);if(kb){Zb=kb.eh;qb=kb.ab;tb=u==1&&r>1&&qb&&(!a.Sd()||a.Td()>=8)}ib=tb||u>=r||!(D&1)?0:d.md;X=(u>1||ib?eb:-1)&d.Wd;var Gb=v,C=[],A,L,Db=a.nf(),mb=Db.Re,G,pb,Ib,rb;Db.Yd&&a.lb(Gb,Db.Yd,([j,"pan-y","pan-x","none"])[X]||"");U=new wc;if(tb)A=new qb(Tb,K,J,kb,mb);a.L(jb,U.ac);a.zb(v,"hidden");L=Vb();a.lb(L,"backgroundColor","#000");a.Mb(L,0);a.kc(L,Gb.firstChild,Gb);for(var cb=0;cb<Q.length;cb++){var tc=Q[cb],uc=new vc(tc,cb);C.push(uc)}a.V(fb);Cb=new xc;z=new jc(Cb,U);if(X){a.g(v,"mousedown",Wb);a.g(v,"touchstart",oc);a.g(v,"dragstart",Hb);a.g(v,"selectstart",Hb);a.g(g,"mouseup",ab);a.g(g,"touchend",ab);a.g(g,"touchcancel",ab);a.g(f,"blur",ab)}E&=mb?10:5;if(Lb&&Fb){Ob=new Fb.ab(Lb,Fb,W(),lb());T.push(Ob)}if(Z&&dc&&ac){Z.pc=D;Z.i=u;Qb=new Z.ab(dc,ac,Z,W(),lb());T.push(Qb)}if(Kb&&db){db.Oc=d.Oc;Mb=new db.ab(Kb,db);T.push(Mb)}a.f(T,function(a){a.Kc(r,C,fb);a.Eb(o.rc,gc)});a.lb(q,"visibility","visible");Eb(W());a.g(v,"click",fc);a.g(q,"mouseout",a.gc(Cc,q));a.g(q,"mouseover",a.gc(Bc,q));xb();d.Ic&&a.g(g,"keydown",function(a){if(a.keyCode==37)ob(-d.Ic);else a.keyCode==39&&ob(d.Ic)});var nb=d.Oc;if(!(D&1))nb=b.max(0,b.min(nb,r-u));z.qc(nb,nb,0)};h.ge=21;h.Zf=22;h.Of=23;h.ef=24;h.ff=25;h.fe=26;h.uf=27;h.Ug=28;h.cf=202;h.bg=203;h.Ie=206;h.Fg=207;h.Jg=208;h.Yc=209;var o={rc:1},q=f.$JssorBulletNavigator$=function(e,C){var f=this;n.call(f);e=a.sb(e);var s,A,z,r,l=0,d,m,k,w,x,h,g,q,p,B=[],y=[];function v(a){a!=-1&&y[a].Qd(a==l)}function t(a){f.o(o.rc,a*m)}f.O=e;f.xc=function(a){if(a!=r){var d=l,c=b.floor(a/m);l=c;r=a;v(d);v(c)}};f.Pc=function(b){a.C(e,b)};var u;f.Kc=function(D){if(!u){s=b.ceil(D/m);l=0;var o=q+w,r=p+x,n=b.ceil(s/k)-1;A=q+o*(!h?n:k-1);z=p+r*(h?n:k-1);a.k(e,A);a.m(e,z);for(var f=0;f<s;f++){var C=a.kg();a.ng(C,f+1);var i=a.bd(g,"numbertemplate",C,c);a.D(i,"absolute");var v=f%(n+1);a.K(i,!h?o*v:f%k*o);a.I(i,h?r*v:b.floor(f/(n+1))*r);a.L(e,i);B[f]=i;d.Fb&1&&a.g(i,"click",a.N(j,t,f));d.Fb&2&&a.g(i,"mouseover",a.gc(a.N(j,t,f),i));y[f]=a.ic(i)}u=c}};f.mc=d=a.r({Hc:10,Jc:10,Cb:1,Fb:1},C);g=a.G(e,"prototype");q=a.k(g);p=a.m(g);a.Pb(g,e);m=d.Zc||1;k=d.ud||1;w=d.Hc;x=d.Jc;h=d.Cb-1;d.sd==i&&a.F(e,"noscale",c);d.hb&&a.F(e,"autocenter",d.hb)},s=f.$JssorArrowNavigator$=function(b,g,h){var d=this;n.call(d);var r,q,e,f,k;a.k(b);a.m(b);function l(a){d.o(o.rc,a,c)}function p(c){a.C(b,c||!h.pc&&e==0);a.C(g,c||!h.pc&&e>=q-h.i);r=c}d.xc=function(b,a,c){if(c)e=a;else{e=b;p(r)}};d.Pc=p;var m;d.Kc=function(d){q=d;e=0;if(!m){a.g(b,"click",a.N(j,l,-k));a.g(g,"click",a.N(j,l,k));a.ic(b);a.ic(g);m=c}};d.mc=f=a.r({Zc:1},h);k=f.Zc;if(f.sd==i){a.F(b,"noscale",c);a.F(g,"noscale",c)}if(f.hb){a.F(b,"autocenter",f.hb);a.F(g,"autocenter",f.hb)}};f.$JssorThumbnailNavigator$=function(g,C){var l=this,A,q,d,w=[],y,x,e,r,s,v,u,p,t,f,m;n.call(l);g=a.sb(g);function B(n,f){var g=this,b,k,i;function p(){k.Qd(q==f)}function h(d){if(d||!t.Ff()){var a=e-f%e,b=t.Rd((f+a)/e-1),c=b*e+e-a;l.o(o.rc,c)}}g.wb=f;g.pd=p;i=n.Ge||n.bc||a.vb();g.ac=b=a.bd(m,"thumbnailtemplate",i,c);k=a.ic(b);d.Fb&1&&a.g(b,"click",a.N(j,h,0));d.Fb&2&&a.g(b,"mouseover",a.gc(a.N(j,h,1),b))}l.xc=function(c,d,f){var a=q;q=c;a!=-1&&w[a].pd();w[c].pd();!f&&t.jg(t.Rd(b.floor(d/e)))};l.Pc=function(b){a.C(g,b)};var z;l.Kc=function(D,C){if(!z){A=D;b.ceil(A/e);q=-1;p=b.min(p,C.length);var j=d.Cb&1,m=v+(v+r)*(e-1)*(1-j),l=u+(u+s)*(e-1)*j,o=m+(m+r)*(p-1)*j,n=l+(l+s)*(p-1)*(1-j);a.D(f,"absolute");a.zb(f,"hidden");d.hb&1&&a.K(f,(y-o)/2);d.hb&2&&a.I(f,(x-n)/2);a.k(f,o);a.m(f,n);var k=[];a.f(C,function(l,g){var h=new B(l,g),d=h.ac,c=b.floor(g/e),i=g%e;a.K(d,(v+r)*i*(1-j));a.I(d,(u+s)*i*j);if(!k[c]){k[c]=a.vb();a.L(f,k[c])}a.L(k[c],d);w.push(h)});var E=a.r({Nc:i,gd:i,Mg:m,yg:l,de:r*j+s*(1-j),dd:12,Gc:200,ce:1,Mc:d.Cb,Wd:d.ch||d.dh?0:d.Cb},d);t=new h(g,E);z=c}};l.mc=d=a.r({Hc:0,Jc:0,i:1,Cb:1,hb:3,Fb:1},C);if(d.Uc!=k)d.i=d.Uc;if(d.q!=k)d.ud=d.q;y=a.k(g);x=a.m(g);f=a.G(g,"slides",c);m=a.G(f,"prototype");v=a.k(m);u=a.m(m);a.Pb(m,f);e=d.ud||1;r=d.Hc;s=d.Jc;p=d.i;d.sd==i&&a.F(g,"noscale",c)};function p(e,d,c){var b=this;l.call(b,0,c);b.xb=a.id;b.Yb=0;b.oc=c}f.$JssorCaptionSlider$=function(h,f,i){var c=this;l.call(c,0,0);var e,d;function g(p,h,f){var c=this,g,n=f?h.Bf:h.ie,e=h.eb,o={fb:"t",p:"d",A:"du",x:"x",y:"y",z:"r",l:"z",s:"f",Hb:"b"},d={Bb:function(b,a){if(!isNaN(a.tb))b=a.tb;else b*=a.df;return b},s:function(b,a){return this.Bb(b-1,a)}};d.l=d.s;l.call(c,0,0);function j(r,m){var l=[],i,k=[],c=[];function h(c,d){var b={};a.f(o,function(g,h){var e=a.j(c,g+(d||""));if(e){var f={};if(g=="t")f.tb=e;else if(e.indexOf("%")+1)f.df=a.tc(e)/100;else f.tb=a.tc(e);b[h]=f}});return b}function p(){return e[b.floor(b.random()*e.length)]}function g(f){var h;if(f=="*")h=p();else if(f){var d=e[a.jc(f)]||e[f];if(a.Lc(d)){if(f!=i){i=f;c[f]=0;k[f]=d[b.floor(b.random()*d.length)]}else c[f]++;d=k[f];if(a.Lc(d)){d=d.length&&d[c[f]%d.length];if(a.Lc(d))d=d[b.floor(b.random()*d.length)]}}h=d;if(a.be(h))h=g(h)}return h}var q=a.U(r);a.f(q,function(b){var c=[];c.O=b;var e=a.j(b,"u")=="caption";a.f(f?[0,3]:[2],function(l,o){if(e){var k,f;if(l!=2||!a.j(b,"t3")){f=h(b,l);if(l==2&&!f.fb){f.p=f.p||{tb:0};f=a.r(h(b,0),f)}}if(f&&f.fb){k=g(f.fb.tb);if(k){var i=a.r({p:0},k);a.f(f,function(c,a){var b=(d[a]||d.Bb).apply(d,[i[a],f[a]]);if(!isNaN(b))i[a]=b});if(!o)if(f.Hb)i.Hb=f.Hb.tb||0;else if(n&2)i.Hb=0}}c.push(i)}if(m%2&&!o)c.U=j(b,m+1)});l.push(c)});return l}function m(w,c,z){var g={n:c.n,H:c.H,R:c.R,fc:f&&!z},m=w,r=a.fd(w),k=a.k(m),j=a.m(m),y=a.k(r),x=a.m(r),h={},e={},i=c.Ue||1;if(c.s)e.s=1-c.s;g.gb=k;g.ib=j;if(c.l||c.z){e.l=(c.l||2)-2;if(a.jb()||a.zc())e.l=b.min(e.l,1);h.l=1;var B=c.z||0;e.z=B*360;h.z=0}else if(c.a){var s={c:0,u:k,v:j,e:0},v=a.r({},s),d=v.Ob={},u=c.a&4,p=c.a&8,t=c.a&1,q=c.a&2;if(u&&p){d.c=j/2*i;d.v=-d.c}else if(u)d.v=-j*i;else if(p)d.c=j*i;if(t&&q){d.e=k/2*i;d.u=-d.e}else if(t)d.u=-k*i;else if(q)d.e=k*i;g.db=c.db;e.a=v;h.a=s}var n=0,o=0;if(c.x)n-=y*c.x;if(c.y)o-=x*c.y;if(n||o||g.db){e.e=n;e.c=o}var A=c.A;h=a.r(h,a.Xg(m,e));g.Cc=a.ld();return new l(c.p,A,g,m,h,e)}function i(b,d){a.f(d,function(d){var a,h=d.O,f=d[0],j=d[1];if(f){a=m(h,f);f.Hb==k&&a.S(b);b=a.cb()}b=i(b,d.U);if(j){var e=m(h,j,1);e.S(b);c.M(e);g.M(e)}a&&c.M(a)});return b}c.xb=function(){c.B(c.cb()*(f||0));g.B(0)};g=new l(0,0);i(0,n?j(p,1):[])}c.xb=function(){d.xb();e.xb()};e=new g(h,f,1);c.Yb=e.cb();c.oc=c.Yb+i;d=new g(h,f);d.S(c.oc);c.M(d);c.M(e)};f.$JssorCaptionSlideo$=function(n,g,m){var b=this,o,h={},i=g.eb,e=new l(0,0);l.call(b,0,0);function j(d,c){var b={};a.f(d,function(d,f){var e=h[f];if(e){if(a.ig(d))d=j(d,c||f=="e");else if(c)if(a.nc(d))d=o[d];b[e]=d}});return b}function k(e,c){var b=[],d=a.U(e);a.f(d,function(d){var h=a.j(d,"u")=="caption";if(h){var e=a.j(d,"t"),g=i[a.jc(e)]||i[e],f={O:d,fb:g};b.push(f)}if(c<5)b=b.concat(k(d,c+1))});return b}function r(c,d,b){a.f(d,function(f){var d=j(f),h={n:a.Bc(d.n),Cc:a.ld(),gb:b.X,ib:b.Y},g=new l(f.b,f.d,h,c,b,d);e.M(g);b=a.Ef(b,d)});return b}function q(b){a.f(b,function(c){var b=c.O,e=a.k(b),d=a.m(b),f={e:a.K(b),c:a.I(b),s:1,Z:a.J(b)||0,z:0,Lb:0,Kb:0,Ab:1,yb:1,Wb:0,Vb:0,Ub:0,Xb:0,Tb:0,X:e,Y:d,a:{c:0,u:e,v:d,e:0}};r(b,c.fb,f)})}function t(g,f,h){var d=g.b-f;if(d){var a=new l(f,d);a.M(e,c);a.S(h);b.M(a)}b.ne(g.d);return d}function s(f){var c=e.vc(),d=0;a.f(f,function(e,f){e=a.r({d:m},e);t(e,c,d);c=e.b;d+=e.d;if(!f||e.t==2){b.Yb=c;b.oc=c+e.d}})}b.xb=function(){b.B(-1,c)};o=[d.Ng,d.Kg,d.Og,d.pb,d.Qc,d.bh,d.ah,d.Vg,d.Rg,d.xg,d.Dg,d.ag,d.Yf,d.Xf,d.Wf,d.Vf,d.cd,d.Qf,d.Nf,d.ed,d.Mf,d.Lf,d.Kf,d.Jf,d.If,d.lg,d.sg,d.rg,d.pg,d.ug,d.mg,d.hg,d.gg,d.Gb,d.Kd,d.Pd,d.Jb];var u={c:"y",e:"x",v:"m",u:"t",z:"r",Lb:"rX",Kb:"rY",Ab:"sX",yb:"sY",Wb:"tX",Vb:"tY",Ub:"tZ",Xb:"kX",Tb:"kY",s:"o",n:"e",Z:"i",a:"c"};a.f(u,function(b,a){h[b]=a});q(k(n,1));e.B(-1);var p=g.jh||[],f=[].concat(p[a.jc(a.j(n,"b"))]||[]);f.push({b:e.cb(),d:f.length?0:m});s(f);b.B(-1)};jssor_1_slider_init=function(){var i=[{A:1200,x:.2,y:-.1,p:20,i:8,q:4,a:15,R:{e:[.3,.7],c:[.3,.7]},P:m.Nb,W:260,n:{e:d.Gb,c:d.Gb,a:d.pb},ub:c,H:{e:1.3,c:2.5}},{A:1500,x:.3,y:-.3,p:20,i:8,q:4,a:15,R:{e:[.1,.9],c:[.1,.9]},Q:c,P:m.Nb,W:260,n:{e:d.Jb,c:d.Jb,a:d.pb},ub:c,H:{e:.8,c:2.5}},{A:1500,x:.2,y:-.1,p:20,i:8,q:4,a:15,R:{e:[.3,.7],c:[.3,.7]},P:m.Nb,W:260,n:{e:d.Gb,c:d.Gb,a:d.pb},ub:c,H:{e:.8,c:2.5}},{A:1500,x:.3,y:-.3,p:80,i:8,q:4,a:15,R:{e:[.3,.7],c:[.3,.7]},n:{e:d.Jb,c:d.Jb,a:d.pb},ub:c,H:{e:.8,c:2.5}},{A:1800,x:1,y:.2,p:30,i:10,q:5,a:15,R:{e:[.3,.7],c:[.3,.7]},Q:c,fc:c,P:m.Nb,W:2050,n:{e:d.cd,c:d.Kd,a:d.Qc},ub:c,H:{c:1.3}},{A:1e3,p:30,i:8,q:4,a:15,Q:c,P:m.Nb,W:2049,n:d.pb},{A:1e3,p:80,i:8,q:4,a:15,Q:c,n:d.pb},{A:1e3,y:-1,i:12,P:m.Fc,Vc:{td:12}},{A:1e3,x:-.2,p:40,i:12,Q:c,P:m.Fc,W:260,n:{e:d.ed,s:d.Qc},s:2,ub:c,H:{c:.5}},{A:2e3,y:-1,p:60,i:15,Q:c,P:m.Fc,n:d.Pd,H:{c:1.5}}],j={Nc:c,Ne:{ab:r,eb:i,Af:1},mf:{ab:s},Ke:{ab:q}},g=new h("jssor_1",j);function e(){var a=g.O.parentNode.clientWidth;if(a){a=b.min(a,600);g.me(a)}else f.setTimeout(e,30)}e();a.g(f,"load",e);a.g(f,"resize",a.Gf(f,e));a.g(f,"orientationchange",e)}}(window,document,Math,null,true,false)

</script>

<style>

.jssorb01{position:absolute}.jssorb01 div,.jssorb01 div:hover,.jssorb01 .av{position:absolute;width:12px;height:12px;filter:alpha(opacity=70);opacity:.7;overflow:hidden;cursor:pointer;border:#000 1px solid}.jssorb01 div{background-color:gray}.jssorb01 div:hover,.jssorb01 .av:hover{background-color:#d3d3d3}.jssorb01 .av{background-color:#fff}.jssorb01 .dn,.jssorb01 .dn:hover{background-color:#555}.jssora05l,.jssora05r{display:block;position:absolute;width:40px;height:40px;cursor:pointer;background:url('img/a17.png') no-repeat;overflow:hidden}.jssora05l{background-position:-10px -40px}.jssora05r{background-position:-70px -40px}.jssora05l:hover{background-position:-130px -40px}.jssora05r:hover{background-position:-190px -40px}.jssora05l.jssora05ldn{background-position:-250px -40px}.jssora05r.jssora05rdn{background-position:-310px -40px}

</style>


<div id="jssor_1" style="position: relative; top: 0px; left: 0px; width: 600px; height: 300px; overflow: hidden; visibility: hidden;">
<!-- Loading Screen -->
<div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
<div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
<div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
</div>
<div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 600px; height: 300px; overflow: hidden;">
<div data-p="112.50" style="display: none;">
<img data-u="image" src="img/01.jpg" />
</div>
<div data-p="112.50" style="display: none;">
<img data-u="image" src="img/02.jpg" />
</div>
<div data-p="112.50" style="display: none;">
<img data-u="image" src="img/03.jpg" />
</div>
<div data-p="112.50" style="display: none;">
<img data-u="image" src="img/04.jpg" />
</div>
</div>
<!-- Bullet Navigator -->
<div data-u="navigator" class="jssorb01" style="bottom:16px;right:16px;">
<div data-u="prototype" style="width:12px;height:12px;"></div>
</div>
<!-- Arrow Navigator -->
<span data-u="arrowleft" class="jssora05l" style="top:0px;left:8px;width:40px;height:40px;" data-autocenter="2"></span>
<span data-u="arrowright" class="jssora05r" style="top:0px;right:8px;width:40px;height:40px;" data-autocenter="2"></span>
<a href="http://www.jssor.com" style="display:none">Bootstrap Carousel</a>
</div>
<script>
jssor_1_slider_init();
</script>


<div id="body1">

<p>প্রধান শিক্ষকের বাণী</p>

<div id="hp">

<img src="Teacher/Ahsan Habib.png" height="180px" width="170px"/>

</div>

<h2 style="text-align:justify; margin-left:20px; margin-top:20px; margin-right:20px; letter-spacing:2px;">আমতলী উচ্চ বিদ্যালয়ের ওয়েবসাইট খুলে সরকারের ডিজিটালাইজেশন কার্যক্রমে অন্তর্ভুক্ত হয়েছে এবং সরকারের ভিশন ২০২১ এর সাথে একাত্মতা প্রকাশ করেছে। আমতলী উচ্চ বিদ্যালয়ের ওয়েবসাইটটিতে যে তথ্য, উপাত্ত থাকবে তা অবাধ তথ্য পাওয়ার অধিকার নিশ্চিত করবে এবং তা সবার কাছে সহজ লভ্য হবে। এটা নিশ্চিত যে, আমাদেরকে ইনফরমেশন হাইওয়েতে উঠতে গেলে, চলতে গেলে তথ্য প্রযুক্তির সর্বোচ্চ ব্যবহার নিশ্চিত করতে হবে। তথ্য প্রযুক্তির ব্যবহার নিশ্চিত করণের মাধ্যমে বিভিন্ন সরকারী দপ্তর, পরিদপ্তর ও অধিদপ্তরের কার্যক্রমে সচ্ছতা, গতিশীলতা, জবাবদিহিতা নিশ্চিত হবে এবং সেবার মান উন্নত হবে ও দুর্নীতি সহনীয় মাত্রায় নেমে আসবে বলে আমার দৃঢ় বিশ্বাস। পরিশেষে আমতলী উচ্চ বিদ্যালয়ের ওয়েবসাইটির সফলতা ও সর্বোত্তম ব্যবহার নিশ্চিত হোক এই কামনা করেই শেষ করছি।</h2>

</div>

<div id="body2">

<p>Recent Activity</p>

</div>



</div>

<div id="bar">

<section class="ac-container">

				<div>
					<input id="ac-1" name="accordion-1" type="checkbox" />
					<label for="ac-1">নোটিশ বোর্ড</label>
					<article class="ac-large">
						
                        <h5 style="margin-left:15px; color:white; font-size:16px; margin-top:20px; height:20px;">
                            
                            
                            <?php



mysql_connect("localhost","amtolihs_sohag","mksbshrmaiu123");
mysql_select_db("amtolihs_admin");

mysql_query('SET CHARACTER SET utf8');
        mysql_query('SET SESSION collation_connection =utf8_general_ci') or die (mysql_error());

$q=mysql_query("Select *from notice ORDER BY id DESC");

   
 $c=0;   
    
while($row=mysql_fetch_array($q))
{

    $c++;
  
  
 echo "<a href=\"admin/".$row["name"]."\">".$row["date"]." : ".$row["title"]."</a>";
    
  echo "<br><br>";  
 
  if($c==4)
  {
      break;
  }

}

    
   

?>

            <a href="#">View All</a>
                            
                        </h5>            
                       
                    </article>
				</div>
				<div>
					<input id="ac-2" name="accordion-1" type="checkbox" />
					<label for="ac-2">ক্লাস রুটিন</label>
					<article class="ac-small">
						<p>Like you, I used to think the world was this great place where everybody lived by the same standards I did, then some kid with a nail showed me I was living in his world, a world where chaos rules not order, a world where righteousness is not rewarded. That's Cesar's world, and if you're not willing to play by his rules, then you're gonna have to pay the price. </p>
					</article>
				</div>
				<div>
					<input id="ac-3" name="accordion-1" type="checkbox" />
					<label for="ac-3">সিলেবাস</label>
					<article class="ac-small">
						<p>You think water moves fast? You should see ice. It moves like it has a mind. Like it knows it killed the world once and got a taste for murder. After the avalanche, it took us a week to climb out. Now, I don't know exactly when we turned on each other, but I know that seven of us survived the slide... and only five made it out. Now we took an oath, that I'm breaking now. We said we'd say it was the snow that killed the other two, but it wasn't. Nature is lethal but it doesn't hold a candle to man. </p>
					</article>
				</div>
				<div>
					<input id="ac-4" name="accordion-1" type="checkbox" />
					<label for="ac-4">পরীক্ষার রুটিন</label>
					<article class="ac-medium">
						<p>You see? It's curious. Ted did figure it out - time travel. And when we get back, we gonna tell everyone. How it's possible, how it's done, what the dangers are. But then why fifty years in the future when the spacecraft encounters a black hole does the computer call it an 'unknown entry event'? Why don't they know? If they don't know, that means we never told anyone. And if we never told anyone it means we never made it back. Hence we die down here. Just as a matter of deductive logic. </p>
					</article>
				</div>

				<div>
					<input id="ac-5" name="accordion-1" type="checkbox" />
					<label for="ac-5">রেজাল্ট</label>
					<article class="ac-medium">
						<p><ul type="circle"><li style="margin-left:20px;"><a href="ssc2015.txt">SSC Result 2015</a></li></ul> </p>
					</article>
				</div>
				</section>

<div id="bar1">

<p>গুরুত্বপূর্ণ লিঙ্ক</p>
<br>
<a href="http://www.educationboard.gov.bd"><img src="arrow.png" style="float:left;"><h2 style="float:left;">জাতীয় শিক্ষা বোর্ড</h3></a><br><hr>
<a href="http://www.nctb.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">ই-বুক</h3></a><br><hr>



<a href="http://www.dinajpureducationboard.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">দিনাজপুর শিক্ষা বোর্ড অফিসিয়াল ওয়েবসাইট</h3></a><br><hr>
<a href="http://www.dshe.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">মাধ্যমিক ও উচ্চ শিক্ষা অধিদপ্তর</h3></a><br><hr>
<a href="http://www.moedu.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">শিক্ষা মন্ত্রনালয়</h3></a><br><hr>
<a href="http://www.teachers.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">শিক্ষক বাতায়ন</h3></a><br><hr>


<a href="http://www.dinajpureducationboard.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">দিনাজপুর শিক্ষা বোর্ড</h3></a><br><hr>
<a href="http://mmc.e-service.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">মাল্টিমিডিয়া ক্লাসরুম ম্যানেজমেন্ট সিস্টেম</h3></a><br><hr>
<a href="http://www.nctb.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">জাতীয় শিক্ষাক্রম ও পাঠ্যপুস্তক বোর্ড</h3></a><br><hr>
<a href="http://www.dinajpur.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">জেলা প্রশাসকের কার্যালয়, দিনাজপুর</h3></a><br><hr>




<a href="http://www.bangladesh.gov.bd/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">বাংলাদেশ জাতীয় তথ্য বাতায়ন</h3></a><br><hr>
<a href="http://educationboardresults.gov.bd"><img src="arrow.png" style="float:left;"><h2 style="float:left;">Education Board Result</h3></a><br><hr>
<a href="http://114.130.64.11/esif/"><img src="arrow.png" style="float:left;"><h2 style="float:left;">eSIF</h3></a><br><hr />

<a href="http://eff.teletalk.com.bd/index.php"><img src="arrow.png" style="float:left;"><h2 style="float:left;">eFF</h3></a><br>

</div>

<div id="bar2">

<p>Calender</p>

   <CENTER>

<SCRIPT LANGUAGE="JavaScript">



<!-- Begin
monthnames = new Array(
"January",
"Februrary",
"March",
"April",
"May",
"June",
"July",
"August",
"September",
"October",
"November",
"Decemeber");
var linkcount=0;
function addlink(month, day, href) {
var entry = new Array(3);
entry[0] = month;
entry[1] = day;
entry[2] = href;
this[linkcount++] = entry;
}
Array.prototype.addlink = addlink;
linkdays = new Array();
monthdays = new Array(12);
monthdays[0]=31;
monthdays[1]=28;
monthdays[2]=31;
monthdays[3]=30;
monthdays[4]=31;
monthdays[5]=30;
monthdays[6]=31;
monthdays[7]=31;
monthdays[8]=30;
monthdays[9]=31;
monthdays[10]=30;
monthdays[11]=31;
todayDate=new Date();
thisday=todayDate.getDay();
thismonth=todayDate.getMonth();
thisdate=todayDate.getDate();
thisyear=todayDate.getYear();
thisyear = thisyear % 100;
thisyear = ((thisyear < 50) ? (2000 + thisyear) : (1900 + thisyear));
if (((thisyear % 4 == 0)
&& !(thisyear % 100 == 0))
||(thisyear % 400 == 0)) monthdays[1]++;
startspaces=thisdate;
while (startspaces > 7) startspaces-=7;
startspaces = thisday - startspaces + 1;
if (startspaces < 0) startspaces+=7;
document.write("<table border=2 bgcolor=white ");
document.write("bordercolor=black><font color=black>");
document.write("<tr><td colspan=7><center><strong>"
+ monthnames[thismonth] + " " + thisyear
+ "</strong></center></font></td></tr>");
document.write("<tr>");
document.write("<td align=center>Sun</td>");
document.write("<td align=center>Mon</td>");
document.write("<td align=center>Tue</td>");
document.write("<td align=center>Wed</td>");
document.write("<td align=center>Thu</td>");
document.write("<td align=center>Fri</td>");
document.write("<td align=center>Sat</td>");
document.write("</tr>");
document.write("<tr>");
for (s=0;s<startspaces;s++) {
document.write("<td> </td>");
}
count=1;
while (count <= monthdays[thismonth]) {
for (b = startspaces;b<7;b++) {
linktrue=false;
document.write("<td>");
for (c=0;c<linkdays.length;c++) {
if (linkdays[c] != null) {
if ((linkdays[c][0]==thismonth + 1) && (linkdays[c][1]==count)) {
document.write("<a href=\"" + linkdays[c][2] + "\">");
linktrue=true;
      }
   }
}
if (count==thisdate) {
document.write("<font color='FF0000'><strong>");
}
if (count <= monthdays[thismonth]) {
document.write(count);
}
else {
document.write(" ");
}
if (count==thisdate) {
document.write("</strong></font>");
}
if (linktrue)
document.write("</a>");
document.write("</td>");
count++;
}
document.write("</tr>");
document.write("<tr>");
startspaces=0;
}
document.write("</table></p>");
// End -->
</SCRIPT>
</CENTER>

</div>


<div id="bar3">

<p>Map</p>

<div id="map"></div>

</div>




</div>




<div id="footer">

  <div id="footer1">
  
     <a href="#">যোগাযোগ</a>
	 <a href="#">গ্যালারি</a>
	  <a href="#">বাণী</a>
	   <a href="admin/index.php">Admin Panel</a>
  
  </div>
  
 
  
  <div id="footer2">
  
  </div>
  
  
  <div id="footer3">
  
    <a href="http://www.facebook.com" target="_blank"><img src="f.png" height="40px" width="40px" /></a>
	 <a href="http://www.tweeter.com" target="_blank"><img src="t.png" height="40px" width="40px" /></a>
	  <a href="http://www.youtube.com"  target="_blank"><img src="y.png" height="40px" width="40px" /></a>
	   <a href="http://www.google.com"  target="_blank"><img src="google.png" height="40px" width="40px" /></a>
	    <a href="http://www.gmail.com.com"  target="_blank"><img src="g.png" height="40px" width="40px" /></a>
  
  
  </div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript" src="http://arrow.scrolltotop.com/arrow7.js"></script>
<noscript>Not seeing a <a href="http://www.scrolltotop.com/">Scroll to Top Button</a>? Go to our FAQ page for more info.</noscript>


  
  </div>

</body>
</html>
